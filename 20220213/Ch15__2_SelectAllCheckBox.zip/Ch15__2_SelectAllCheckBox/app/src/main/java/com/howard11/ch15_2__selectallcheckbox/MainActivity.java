package com.howard11.ch15_2__selectallcheckbox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         ArrayList<CheckBox> itemList = new ArrayList<>();

        CheckBox allCb =  findViewById(R.id.allCB);
        CheckBox item1Cb =  findViewById(R.id.item1CB);
        CheckBox item2Cb =  findViewById(R.id.item2CB);
        CheckBox item3Cb =  findViewById(R.id.item3CB);
        CheckBox item4Cb =  findViewById(R.id.item4CB);

        Button submitBtn = findViewById(R.id.subnitBtn);

        View.OnClickListener itemCbOnClickListener = (btn)->{
            CheckBox itemCheckBox = (CheckBox)btn;
            boolean isChecked = itemCheckBox.isChecked();
            if (isChecked){
                isChecked = itemList.stream().allMatch(CheckBox::isChecked);
            }
            allCb.setChecked(isChecked);
        };

        item1Cb.setOnClickListener(itemCbOnClickListener);
        item2Cb.setOnClickListener(itemCbOnClickListener);
        item3Cb.setOnClickListener(itemCbOnClickListener);
        item4Cb.setOnClickListener(itemCbOnClickListener);

        itemList.add(item1Cb);
        itemList.add(item2Cb);
        itemList.add(item3Cb);
        itemList.add(item4Cb);

        allCb.setOnClickListener((btn)->{
                 CheckBox allBox =(CheckBox)btn;
                for (CheckBox box : itemList){
                    box.setChecked(allBox.isChecked());
                }
            Log.d("Howard","isChecked:"+allBox.isChecked());

        });

        submitBtn.setOnClickListener(v->{

          String msg=   itemList.stream().filter(CheckBox::isChecked).
                    map(c->c.getText().toString()).collect(Collectors.joining(","));
          if (msg.isEmpty()){
              msg = "無";
          }
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();

        });
    }
}