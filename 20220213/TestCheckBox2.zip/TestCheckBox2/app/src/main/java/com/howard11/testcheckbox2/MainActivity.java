package com.howard11.testcheckbox2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<CheckBox> listBox = new ArrayList();
       CheckBox itemCB1 =  findViewById(R.id.item1CB);
       CheckBox itemCB2 =  findViewById(R.id.item2CB);
       CheckBox itemCB3 =  findViewById(R.id.item3CB);
        listBox.add(itemCB1);
        listBox.add(itemCB2);
        listBox.add(itemCB3);

       TextView msgView = findViewById(R.id.msgView);
       Button submitBtn =  findViewById(R.id.submitBtn);
        submitBtn.setOnClickListener(v->{
            msgView.setText("");
              String msg =  listBox.stream().filter(CheckBox::isChecked).
            map(c->c.getText().toString()).collect(Collectors.joining(","));

//            StringBuffer msg = new StringBuffer();
//            for(CheckBox c : listBox){
//                if (c.isChecked()){
//                    msg.append(c.getText().toString()+" ");
//                }
//            }
//            //String msg = itemCB1.getText().toString();
            msgView.setText(msg);

        });

    }
}
