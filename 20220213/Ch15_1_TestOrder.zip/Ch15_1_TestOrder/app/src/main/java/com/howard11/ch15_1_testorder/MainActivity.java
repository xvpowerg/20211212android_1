package com.howard11.ch15_1_testorder;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

import com.howard11.ch15_1_testorder.tools.OrderUI;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private OrderUI orderUi = null;
    private void init(){
        orderUi = new OrderUI();
        CheckBox c1 = findViewById(R.id.item1CB);
        CheckBox c2 = findViewById(R.id.item2CB);
        CheckBox c3 = findViewById(R.id.item3CB);
        orderUi.appendItemCheckBox(c1,c2,c3);

        EditText ed1 = findViewById(R.id.countText1);
        EditText ed2 = findViewById(R.id.countText2);
        EditText ed3 = findViewById(R.id.countText3);
        orderUi.appendCountEditText(ed1,ed2,ed3);

        RadioButton rb1 = findViewById(R.id.takeRB1);
        RadioButton rb2 = findViewById(R.id.takeRB2);
        orderUi.appendTakeRadioButton(rb1,rb2);


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        Button btn = findViewById(R.id.submitBtn);
        btn.setOnClickListener(v->{
           boolean b1 = orderUi.verifyData();
            Log.d("Howard","b1:"+b1);

        });
    }
}