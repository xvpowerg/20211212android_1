package com.howard11.ch15_1_testorder.bean;

import java.util.ArrayList;
import java.util.List;

public class LunchBox {
    private List<Item> items = new ArrayList<>();
    private OrderTackStatus status = OrderTackStatus.OUT;
    public enum OrderTackStatus{
        OUT,
        IN
    }




}
