package com.howard11.ch15_1_testorder.tools;

import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

import com.howard11.ch15_1_testorder.bean.LunchBox;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Consumer;

public class OrderUI {
    private List<CheckBox> itemCheckBoxList = new ArrayList<>();
    private List<EditText> countEditTextList = new ArrayList<>();
    private Map<Integer, RadioButton> radioButtonMapMap = new HashMap<>();
    private int countMax = 10000;
    private List<String> verifyMsgList = new ArrayList<>();
//    public String getSelectedOrder(){
//        return "";
//    }

    public void appendItemCheckBox(CheckBox... checkboxs){
        for (CheckBox cb : checkboxs){
            itemCheckBoxList.add(cb);
        }

    }
    public void appendTakeRadioButton(RadioButton... radioButtons){
        for (RadioButton rb : radioButtons){
            radioButtonMapMap.put(rb.getId(),rb);
        }
    }

    public void appendCountEditText(EditText... editTexts){
        for (EditText editText : editTexts){
            countEditTextList.add(editText);
        }
    }


    private void loopIsCheckedCBList(BiFunction<Integer,CheckBox, Boolean> func,
                                     Consumer<CheckBox> passAction,
                                     Consumer<CheckBox> failAction){
        for(int index = 0; index <itemCheckBoxList.size() ; index++){
            CheckBox checkBox = itemCheckBoxList.get(index);
            if (checkBox.isChecked()) {
               boolean pass =  func.apply(index,checkBox);
               if (passAction != null && pass){
                   passAction.accept(checkBox);
               }else if(failAction!= null && !pass){
                   failAction.accept(checkBox);
               }
            }
        }
    }

    public boolean verifyData(){
        verifyMsgList.clear();
        loopIsCheckedCBList((index,checkBox) ->{
           EditText editText = countEditTextList.get(index);
            String countStr =  editText.getText().toString().trim();
            if (countStr.isEmpty() || Integer.parseInt(countStr) == 0 ||
                    Integer.parseInt(countStr) > countMax){
                return false;
            }
            return true;
        },null,checkBox -> {
            verifyMsgList.add(checkBox.getText().toString()+"數量錯誤");
        } );
    //假設verifyMsgList 有訊息表示有錯誤 驗證無法通過
        return verifyMsgList.size() == 0;
    }

    public void submitData(Consumer<LunchBox> action){
        LunchBox lunchBox = null;
        action.accept(lunchBox);

    }

}
