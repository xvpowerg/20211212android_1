package com.howard11.ch14_4_radiobtn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private String msg = "請選狀態";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Map<Integer,RadioButton> rbMap = new HashMap<>();
        RadioButton rb1 =  findViewById(R.id.status1);
        RadioButton rb2 = findViewById(R.id.status2);
        RadioButton rb3 =findViewById(R.id.status3);
        rbMap.put(R.id.status1,rb1);
        rbMap.put(R.id.status2,rb2);
        rbMap.put(R.id.status3,rb3);
       Button submitBtn =  findViewById(R.id.submitBtn);

       RadioGroup radioGroup =  findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener((group,checkId)->{
            Log.d("Howard","checkId:"+checkId);
            RadioButton rb = rbMap.get(checkId);
            Log.d("Howard","Text:"+rb.getText());
            msg = rb.getText().toString();
        });
        submitBtn.setOnClickListener(v->{
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();

        });
    }
}