package com.howard11.ch14_3_checkbox3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {
    private List<CheckBox> checkBoxList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ViewGroup checkBoxGroup = findViewById(R.id.checkBoxGroup);
        Button submitBtn = findViewById(R.id.submitBtn);
        for (int i =0; i <checkBoxGroup.getChildCount() ;i++){
           CheckBox checkBox = (CheckBox)  checkBoxGroup.getChildAt(i);
            checkBoxList.add(checkBox);
        }

        submitBtn.setOnClickListener(v->{

            String msg = checkBoxList.stream().filter(CheckBox::isChecked).
                    map(c->c.getText().toString()).collect(
                    Collectors.joining(","));
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();

        });
    }
}