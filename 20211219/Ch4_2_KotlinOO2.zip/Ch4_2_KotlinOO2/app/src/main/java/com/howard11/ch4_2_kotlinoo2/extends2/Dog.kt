package com.howard11.ch4_2_kotlinoo2.extends2

class Dog : Animal {
    //:super() 呼叫父類別的建構式
    constructor():super(){}
    constructor(name:String,age:Int,height:Float):super(name,age,height){

    }
}