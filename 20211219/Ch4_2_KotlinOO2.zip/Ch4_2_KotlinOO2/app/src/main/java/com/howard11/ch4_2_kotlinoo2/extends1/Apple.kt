package com.howard11.ch4_2_kotlinoo2.extends1

class Apple(id:String="",name:String="",price:Int=0):Fruit(id,name,price) {

}