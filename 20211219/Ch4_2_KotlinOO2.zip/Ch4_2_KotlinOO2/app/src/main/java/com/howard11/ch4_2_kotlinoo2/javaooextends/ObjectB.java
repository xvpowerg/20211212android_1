package com.howard11.ch4_2_kotlinoo2.javaooextends;

public class ObjectB extends ObjectA {
    ObjectB(int v){
        super(v);
    }
}
