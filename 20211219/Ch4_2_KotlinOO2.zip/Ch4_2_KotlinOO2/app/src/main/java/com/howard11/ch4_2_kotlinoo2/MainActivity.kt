package com.howard11.ch4_2_kotlinoo2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.howard11.ch4_2_kotlinoo2.extends1.Apple

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val apple = Apple("Apple 0002","Red Apple",600)
        Log.d("Howard","apple1:${apple.name}:${apple.price}")
        apple.print()
    }
}