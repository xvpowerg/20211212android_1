package com.howard11.ch4_2_kotlinoo2.extends1

import android.util.Log

//加上open才可繼承
open class Fruit(var id:String = "",
                 var name:String = "",
                 var price:Int = 0) {

    fun  print(){
        Log.d("Howard","$id : $name  : $price")
    }

}