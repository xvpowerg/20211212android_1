package com.howard11.ch4_2_kotlinoo2.javaooextends;

public class ObjectA {
    int v;
    ObjectA(int v){
        this.v = v;
    }
}
