package com.howard11.ch4_2_kotlinoo2.extends2

open class Animal {
    var height:Float = 0.0f
    var name:String = ""
    var age:Int = 0
    constructor(){}
    constructor(name:String,age:Int,height:Float){
        ///呼叫函數.....
        this.name = name
        this.age = age
        this.height = height
    }
}