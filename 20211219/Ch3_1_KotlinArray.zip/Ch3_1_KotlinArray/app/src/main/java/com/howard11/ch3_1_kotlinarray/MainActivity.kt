package com.howard11.ch3_1_kotlinarray

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //testArray1()
        //testArray2()
        //testArray3()
        //testArray4()
        testArray5()
    }

    fun testArray1(){
        val names = arrayOf("力宏","若瑄","yumi")
        Log.d("Howard","name:"+names[0])

        for (i in 0 until names.size){
                Log.d("Howard","name${names[i]}")
        }
        Log.d("Howard","============================")
        for (name in names){
            Log.d("Howard","name:$name")
        }

        names.forEachIndexed { index, s -> Log.d("Howard","$index : $s") }
    }

    fun testArray2(){
        val array0 = arrayOf(30,10,"AA",3.5)
        array0.forEach {
            when(it){
               is Int ->Log.d("Howard","value is Int:")
               is String ->Log.d("Howard","Values is String")
               else ->Log.d("Howard","Error: ${it.javaClass.name}")
            }
        }
            Log.d("Howard","===============================")
        val array1 = arrayOf<Int>(30,18,17)
        var sum = 0
        array1.forEach { sum += it }
        Log.d("Howard","sum:$sum")

    }

    fun testArray3(){
        val defArray = Array<String>(5){index->"value:$index"}
        defArray.forEach { Log.d("Howard",it) }
    }

    fun testArray4(){
        val defArray = Array<Int>(10){ Random.nextInt(1,100) }
        val value2 = defArray.joinToString()
        Log.d("Howard","value:$value2")
        defArray.sort()//defArray會排序
        //defArray.sortedArray()//defArray不會真的排序 而是建立新陣列排序

        val value3 = defArray.joinToString()
        Log.d("Howard","value3:$value3")

        val value4 = defArray.sortedArrayDescending()//defArray不會真的排序 而是建立新陣列排序
        val v4 = value4.joinToString()
        Log.d("Howard","value4:$v4")
        val v5 = defArray.joinToString()
        Log.d("Howard","value5:$v5")

        defArray.sortDescending()//defArray不會真的排序 而是建立新陣列排序
        Log.d("Howard","value6:${defArray.joinToString()}")
    }


    fun testArray5(){
            //val intArray = arrayOf<Int>(20,50,60)
            //TestJava.foreachIntArray(intArray)
        val intArray2 = IntArray(5){it}//基本型態的!!
        Log.d("Howard",intArray2.javaClass.name)
        TestJava.foreachIntArray(intArray2)

        val intArray3  = intArrayOf(10,20,50,60)//先初始化陣列
        TestJava.foreachIntArray(intArray3)

        val nameArray4 = arrayOf<String>("Ken","Vivin","Lindy")
        TestJava.foreachStringArray(nameArray4)
    }



}