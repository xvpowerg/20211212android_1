package com.howard11.ch3_1_kotlinarray;

import android.util.Log;

public class TestJava {

    public static void foreachIntArray(int[] array){
         for (int v : array){
             Log.d("Howard","IntArray V:"+v);
         }
    }

    public static void foreachStringArray(String[] data){
        for (String v : data){
            Log.d("Howard","StringArray V:"+v);
        }
    }

}
