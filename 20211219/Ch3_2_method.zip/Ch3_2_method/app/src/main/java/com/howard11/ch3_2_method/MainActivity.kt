package com.howard11.ch3_2_method

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val testMethod = TestMethod()
        testMethod.test1()
        val ans = testMethod.test2(10f,5f)
        Log.d("Howard","ans:$ans")
        testMethod.initBox()
        testMethod.initBox(20,5,"8")
        testMethod.initBox( id="A",width = 10)

        val sum1 = testMethod.sum(5,4,3,2,1)
        Log.d("Howard","Sum1:$sum1")
        val sum2 = testMethod.sum()
        Log.d("Howard","Sum1:$sum2")
        val nameStr =
            testMethod.joinNames(title = "RD:", end = ".", "Ken","Vivin","Lindy")
        Log.d("Howard",nameStr)

        val result = testMethod.cmp(6,9,11,25,14,8,cmpType=2)
        Log.d("Howard","result:$result")

        testMethod.printNames("A","B","C","D")


    }
}