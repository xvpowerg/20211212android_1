package com.howard11.ch4_1_kotlinoo.kotlinoo

class Toy {

    var price:Int = 0
    var name:String = ""
    constructor(){}
    constructor(price:Int,name:String){
        this.price = price
        this.name = name
    }


}