package com.howard11.ch4_1_kotlinoo.kotlinoo

import android.util.Log

class Person {

    var name:String = ""
    get(){
        return field
    }
    set(value){
        Log.d("Howard","set name:$value")
        field = value
    }
    var age:Int = 0
    get(){
        return field
    }
    set(value){
        Log.d("Howard","set name:$value")
        field = value
    }

    var myToy:Toy
    constructor(){
        this.myToy = Toy()
    }

}