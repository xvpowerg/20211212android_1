package com.howard11.ch4_1_kotlinoo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.howard11.ch4_1_kotlinoo.javaoo.Student
import com.howard11.ch4_1_kotlinoo.kotlinoo.Person
import java.time.LocalDate
import java.time.LocalDateTime

class MainActivity : AppCompatActivity() {
    var dataTime:LocalDateTime = LocalDateTime.now()

    fun test(obj:MainActivity){

    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val st1 = Student()
        st1.setAge(10)
        st1.setName("Ken")

        Log.d("Howard","Student1:${st1.getName()}:${st1.getAge()}")
        val st2 = Student("Vivin",12)
        Log.d("Howard","Student2:${st2.getName()}:${st2.getAge()}")

        var p1 = Person()
        p1.name = "Ken"
        p1.age = 10

        Log.d("Howard","name ${p1.name} : ${p1.age} ")

        var p2= Person()
        //回傳當前物件
        p2.also {
            //當前物件叫it 好處是可使用this(代表目前類別)
           Log.d("Howard","dataTime:${this.dataTime}")
            //startActivity()
            test(this)
            it.age = 15
        }.also {
            it.name = "Lucy"
        }

        Log.d("Howard","name: ${p2.name} age:${p2.age}")

        p2.apply {
            name = "joy"
            age = 26
        }
        Log.d("Howard","name:${p2.name} age:${p2.age}")

        //回傳最後一個數值
        //it表示目前物件
        //如果不需要使用this表示其他物件時
        var obj3 = Person()
        obj3.let {
           it.name = "Iris"
           it.age = 2
           it.myToy
        }.apply {
            price = 80
            name = "芭比！"
        }
        Log.d("Howard","${obj3.name} : ${obj3.age }:${obj3.myToy.name}")

        //回傳最後一個數值
        //this表示目前物件
        //如果不需要使用this表示其他物件時
        val obj4 = Person()
        val pass = obj4.run {
            name= "Bon"
            age = 15
            age >= 18
        }
        if (pass){
            Log.d("Howard","${obj4.name}過關")
        }else{
            Log.d("Howard","${obj4.name}未過關")
        }
        //回傳最後一個數值
        //可傳一組參數作為設定this的依據
        //this表示目前物件
        //如果不需要使用this表示其他物件時

        val obj5 = Person()
        val stObj = with(obj5){
            name = "join"
            age = 82
            this
        }
        Log.d("Howard","name:${stObj.name} age:${stObj.age}")

    }
}