package com.howard11.ch8_1_bmi_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       EditText heightEdit =  findViewById(R.id.heightET);
       EditText weightET =  findViewById(R.id.weightET);
       Button submitBtn = findViewById(R.id.submitBtn);
        submitBtn.setOnClickListener(v->{

            String heightStr = heightEdit.getText().toString();
            String weightStr = weightET.getText().toString();
            int height = 0;
            int weight = 0;
            String msg = "";
            try{
                 height = Integer.parseInt(heightStr);
            }catch(NumberFormatException ex){
//                Toast.makeText(this,getString(R.string.height_empty_error),
//                        Toast.LENGTH_LONG).show();
                msg+=getString(R.string.height_empty_error);
            }


            try{
                weight = Integer.parseInt(weightStr);
            }catch(NumberFormatException ex){
//                Toast.makeText(this,getString(R.string.weight_empty_error),
//                        Toast.LENGTH_LONG).show();
                msg+=getString(R.string.weight_empty_error);
            }

            if (!msg.isEmpty()){
                Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
            }else{
                float bmi = weight / (float)Math.pow(height/100f,2);
                showStatusMsg(bmi);
                Log.d("Howard","BMI:"+bmi);
            }

        });

    //BMI > 40 危險 bmi_status_danger
    //BMI > 30 過高 bmi_status_too_height
    //BMI > 26 高 bmi_status_height
    //BMI > 20 正常 bmi_status_normal
    }

   private void showStatusMsg(float bmi){
        String msg = getString(R.string.bmi_status_normal);
        if (bmi > 40){
            msg = getString(R.string.bmi_status_danger);
        }else if(bmi > 30){
            msg = getString(R.string.bmi_status_too_height);
        }else if(bmi > 26){
            msg = getString(R.string.bmi_status_height);
        }
        Log.d("Howard","msg:"+msg);
   }
}