package com.howard11.ch8_2_intent_bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn =  findViewById(R.id.submitBtn);
        btn.setOnClickListener(v->{
            EditText heightET = findViewById(R.id.heightET);
            EditText weightET = findViewById(R.id.weightET);
            String heightStr = heightET.getText().toString();
            String weightStr = weightET.getText().toString();
            Intent toPage2 = new Intent(this,Page2Activity.class);
            toPage2.putExtra("height",heightStr);
            toPage2.putExtra("weight",weightStr);
            startActivity(toPage2);

        });
    }
}