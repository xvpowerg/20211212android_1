package com.howard11.ch8_2_intent_bmi;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Page2Activity  extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page2_layout);
        Intent data =  getIntent();
        String height = data.getStringExtra("height");
        String weight = data.getStringExtra("weight");
        TextView heightTxt = findViewById(R.id.heightTxt);
        TextView weightTxt = findViewById(R.id.weightTxt);
        //Log.d("Howard","Height:"+height);
        heightTxt.setText(heightTxt.getText()+":"+height);
    }
}
