package com.howard11.java_android_bmi.function;

import com.howard11.java_android_bmi.R;

public class BmiFunction {

    public static int bmiStatusId(double bmi){
        if (bmi < 20){
            return R.string.bmi_low;
        }else if(bmi < 26){
            return R.string.bmi_normal;
        }else if(bmi < 30){
            return R.string.bmi_mild_obesity;
        }else if(bmi < 40){
            return R.string.bmi_moderate_obesity;
        }else if(bmi <= 100 ){
            return R.string.bmi_height_obesity;
        }
        return R.string.bmi_over_height_obesity;
    }
}
