package com.howard11.java_android_bmi;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity_Old extends AppCompatActivity {
//MVC
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            EditText heightEdit = findViewById(R.id.heightEdit);
            EditText weightEdit = findViewById(R.id.weightEdit);
            Button bmiBtn = findViewById(R.id.bmiBtn);
            TextView bmiTxt =  findViewById(R.id.bmiTxt);
            bmiBtn.setOnClickListener(v->{
                String heightStr = heightEdit.getText().toString();
                String weightStr = weightEdit.getText().toString();
                float height = Integer.parseInt(heightStr);
                height /= 100; //公分轉公尺
                int weight = Integer.parseInt(weightStr);
                double bmi = weight / Math.pow(height,2);
                String msg = "";
                if (bmi < 20){
                    msg = getString(R.string.bmi_low);
                }else if(bmi < 26){
                    msg = getString(R.string.bmi_normal);
                }else if(bmi < 30){
                    msg = getString(R.string.bmi_mild_obesity);
                }else if(bmi < 40){
                    msg = getString(R.string.bmi_moderate_obesity);
                }else if(bmi <= 100){
                    msg = getString(R.string.bmi_height_obesity);
                }else{
                    msg = getString(R.string.bmi_over_height_obesity);;
                }
                String bmiMsg = String.format("BMI:%.2f 狀態:%s",bmi,msg);
                bmiTxt.setText(bmiMsg);
            });



    }
}