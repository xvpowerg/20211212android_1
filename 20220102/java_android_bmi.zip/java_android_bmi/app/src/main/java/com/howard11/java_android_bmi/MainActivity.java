package com.howard11.java_android_bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.howard11.java_android_bmi.function.BmiFunction;
import com.howard11.java_android_bmi.model.BmiModel;

public class MainActivity extends AppCompatActivity {
//MVC
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            EditText heightEdit = findViewById(R.id.heightEdit);
            EditText weightEdit = findViewById(R.id.weightEdit);
            Button bmiBtn = findViewById(R.id.bmiBtn);
            TextView bmiTxt =  findViewById(R.id.bmiTxt);
            bmiBtn.setOnClickListener(v->{
                String heightStr = heightEdit.getText().toString();
                String weightStr = weightEdit.getText().toString();
                BmiModel bmiModel = new BmiModel(heightStr,weightStr);
                double bmi = bmiModel.calculatorBmi();
                int resid = bmiModel.getBMIStatusID(BmiFunction::bmiStatusId);
                 String msg = getString(resid);
                String bmiMsg = String.format("BMI:%.2f 狀態:%s",bmi,msg);
                bmiTxt.setText(bmiMsg);
            });



    }
}