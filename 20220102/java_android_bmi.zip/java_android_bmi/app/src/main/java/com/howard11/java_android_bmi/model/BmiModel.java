package com.howard11.java_android_bmi.model;
import java.util.function.Function;
public class BmiModel {
        private float height,weight;
        private double bmi = -1;
    public BmiModel(float height,float weight){
        this.height = height;
        this.weight = weight;
    }
    public BmiModel(String heightStr,String weightStr){
        this(Float.parseFloat(heightStr),Float.parseFloat(weightStr));
    }

    public double calculatorBmi(){
        height /= 100;
        bmi = weight / Math.pow(height,2);
        return bmi;
    }

    public   int getBMIStatusID(Function<Double,Integer> bmiFunc ){
                if (bmi == -1){
                    throw new  IllegalStateException("not call calculatorBmi()");
                }
            return bmiFunc.apply(bmi);
    }



}
