package com.howard11.ch7_2_activitytoactivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Activity2 extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2_layout);
        Button toAc3Btn =  findViewById(R.id.toActivity2Btn);
        Button toAc1Btn =  findViewById(R.id.toActivity1Btn);
        toAc3Btn.setOnClickListener(v->{
            Intent toActivity = new Intent(this,Activity3.class);
            startActivity(toActivity);
        });

        toAc1Btn.setOnClickListener(v->{
                finish();
        });
    }
}
