package com.howard11.ch7_2_activitytoactivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Activity3 extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acticity3_layout);
        Button btn3 = findViewById(R.id.toActivity2Btn);

        btn3.setOnClickListener(v->{
//            Intent toActivity2 = new Intent(this,Activity2.class);
//            startActivity(toActivity2);
               finish();
        });

    }


}
