package com.howard11.ch8_1_activity_intent_buding;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button sendBtn = findViewById(R.id.sendMsgBtn);
        Button ageBtn =   findViewById(R.id.sendAgeBtn);

        TextView msgTxt =  findViewById(R.id.msgTxt);
        EditText ageEdit = findViewById(R.id.ageEdit);

        sendBtn.setOnClickListener(v->{
            Intent toActivity = new Intent(this,Activity2.class);
            String msgValue= msgTxt.getText().toString();
            //map k v
            toActivity.putExtra("msg",msgValue);//帶資訊
            startActivity(toActivity);
        });
        ageBtn.setOnClickListener(v->{
                Intent toActivity = new Intent(this,
                        Activity2.class);
                 String ageStr = ageEdit.getText().toString();
            toActivity.putExtra("age",Double.parseDouble(ageStr));
            startActivity(toActivity);
        });


    }
}