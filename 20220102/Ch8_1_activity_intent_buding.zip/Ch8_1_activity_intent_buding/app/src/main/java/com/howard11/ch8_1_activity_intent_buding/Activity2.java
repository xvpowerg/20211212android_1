package com.howard11.ch8_1_activity_intent_buding;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Activity2 extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2_layout);
        TextView msgView =   findViewById(R.id.msgView);
        String msg = "";
        //取得上一個Activity 傳過來的Intent
        Intent dataIntent =  getIntent();
        if (dataIntent.getStringExtra("msg") != null){
            msg = dataIntent.getStringExtra("msg");
        }else{
            double age = dataIntent.
                    getDoubleExtra("age",0);
            msg = age+"";
        }
        msgView.setText(msg);
    }
}
