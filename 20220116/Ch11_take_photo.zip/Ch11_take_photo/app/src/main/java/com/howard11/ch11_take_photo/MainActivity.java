package com.howard11.ch11_take_photo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView photoView;
    private  Bitmap bitmap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("Howard","onCreate!!"+savedInstanceState);

        setContentView(R.layout.activity_main);
        Button photoBtn = findViewById(R.id.photoBtn);
        photoView =  findViewById(R.id.photoView);
        photoBtn.setOnClickListener(v->{
            Intent it = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(it,100);
        });
    }
    //恢復數值
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d("Howard","onRestoreInstanceState");
        bitmap =  savedInstanceState.getParcelable("bitmap");
        if (bitmap != null){
            photoView.setImageBitmap(bitmap);
        }
    }

    //存儲數值
    //onDestroy 之前
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d("Howard","onSaveInstanceState");
        outState.putParcelable("bitmap",bitmap);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("Howard","onActivityResult 1");
        Log.d("Howard","onActivityResult 1");
        if (requestCode == 100  && data != null){
            Log.d("Howard","onActivityResult 2");
            bitmap = (Bitmap) data.getExtras().get("data");
            photoView.setImageBitmap(bitmap);
        }

    }
//    @Override
//    protected void onRestart() {
//        super.onRestart();
//        Log.d("Howard","onRestart");
//
//    }

//    @Override
//    protected void onStart() {
//        super.onStart();
//        Log.d("Howard","onStart");
//    }
//
//
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        Log.d("Howard","onResume");
//    }
//
    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Howard","onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Howard","onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy");
    }


}
