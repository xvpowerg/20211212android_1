package com.howard11.ch11_2_take_photo2;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView photoView;
    private Bitmap bitmap;
//    private ActivityResultLauncher launcher = registerForActivityResult(
//            new TakePhotoContract(),(Bitmap bitmp)->{
//                this.bitmap = bitmp;
//                photoView.setImageBitmap(bitmp);
//            });

    private ActivityResultLauncher<Void> launcher =
            registerForActivityResult(new ActivityResultContracts.TakePicturePreview(),
            (Bitmap bmp)->{
                bitmap = bmp;
                photoView.setImageBitmap(bitmap);
            });
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("Howard","onCreate!!"+savedInstanceState);
        setContentView(R.layout.activity_main);
        Button photoBtn = findViewById(R.id.photoBtn);
        photoView =  findViewById(R.id.photoView);
        photoBtn.setOnClickListener(v->{
            //ctivityResultContracts.StartActivityForResult
            launcher.launch(null);
        });
    }

private class TakePhotoContract  extends ActivityResultContract<Void,Bitmap> {
    @NonNull
    @Override
    public Intent createIntent(@NonNull Context context, Void input) {
         Intent it = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        return it;
    }

    @Override
    public Bitmap parseResult(int resultCode, @Nullable Intent intent) {
        if (resultCode != RESULT_OK){ return null;}
        return intent.getParcelableExtra("data");
    }
}

    //恢復數值
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d("Howard","onRestoreInstanceState");
        bitmap =  savedInstanceState.getParcelable("bitmap");
        if (bitmap != null){
            photoView.setImageBitmap(bitmap);
        }
    }

    //存儲數值
    //onDestroy 之前
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d("Howard","onSaveInstanceState");
        outState.putParcelable("bitmap",bitmap);
    }

}