package com.howard11.ch12_2_intentsahre2

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val shareBtn = findViewById<Button>(R.id.shareTxtBtn)
        val shareImageBtn = findViewById<Button>(R.id.shareImageBtn)
        val msgTxt =    findViewById<EditText>(R.id.msgTxt)
        shareBtn.setOnClickListener {
            val sendTextIntent = Intent()
            sendTextIntent.action = Intent.ACTION_SEND
            val msg =  msgTxt.text.toString()
            sendTextIntent.putExtra(Intent.EXTRA_TEXT,msg)
            sendTextIntent.type = "text/plain"
            startActivity(Intent.createChooser(sendTextIntent,"請選分享對象"))
        }
        shareImageBtn.setOnClickListener {
            val shareImageIntent = Intent()
            val uri = Uri.parse("android.resource://"+applicationContext.packageName+
                    "/" + R.drawable.image2)
            shareImageIntent.action = Intent.ACTION_SEND
            shareImageIntent.putExtra(Intent.EXTRA_STREAM,uri)
            shareImageIntent.type = "image/jpg"
            startActivity(Intent.createChooser(shareImageIntent,"請選擇分享對象"))
        }

    }
}