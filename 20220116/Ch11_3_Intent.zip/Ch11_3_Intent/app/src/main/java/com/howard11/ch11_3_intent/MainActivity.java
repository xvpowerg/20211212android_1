package com.howard11.ch11_3_intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       Button page2Btn =  findViewById(R.id.page2Btn);
       Button page3Btn =  findViewById(R.id.page3Btn);
        page2Btn.setOnClickListener(v->{

            Intent toPage2 = new Intent(MainActivity.this,ActivityPage2.class);
            startActivity(toPage2);
        });

        page3Btn.setOnClickListener(v->{
            Intent toPage3 = new Intent("com.howard11.PAGE3");
            startActivity(toPage3);

        });
    }
}