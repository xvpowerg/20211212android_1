package com.howard11.ch12_1_intentshare;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         Button shareTxtBtn =  findViewById(R.id.shareTxtBtn);
         Button shareImageBtn = findViewById(R.id.shareImageBtn);
        shareTxtBtn.setOnClickListener(v->{
            Intent sendTextIntent = new Intent();
            //內容是文字
            sendTextIntent.putExtra(Intent.EXTRA_TEXT,"Share Value");
            sendTextIntent.setAction(Intent.ACTION_SEND);
            //類型是文字
            sendTextIntent.setType("text/plain");
            startActivity(Intent.createChooser(sendTextIntent,"請選分享對象"));

        });
        shareImageBtn.setOnClickListener(v->{
            Intent shareImageIntent = new Intent(Intent.ACTION_SEND);
            Uri uri =  Uri.parse("android.resource://"+
                    getApplicationContext().getPackageName()+"/"+
                    R.drawable.image1);
            shareImageIntent.putExtra(Intent.EXTRA_STREAM,uri);
            shareImageIntent.setType("image/jpg");
            startActivity(Intent.createChooser(shareImageIntent,"請選分享對象"));

        });
    }
}