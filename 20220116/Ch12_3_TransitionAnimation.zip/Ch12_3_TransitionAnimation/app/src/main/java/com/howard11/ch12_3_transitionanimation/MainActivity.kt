package com.howard11.ch12_3_transitionanimation

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val f1Btn =  findViewById<Button>(R.id.f1Btn)
        val f2Btn = findViewById<Button>(R.id.f2Btn)
        val f3Btn = findViewById<Button>(R.id.f3Btn)

        f1Btn.setOnClickListener {  }
        f2Btn.setOnClickListener {
            val toDetail = Intent(this,
                DetailActivity::class.java)
            toDetail.putExtra("type",Fruit.CHERRY)
            startActivity(toDetail)

        }
        f3Btn.setOnClickListener {


        }
    }
}