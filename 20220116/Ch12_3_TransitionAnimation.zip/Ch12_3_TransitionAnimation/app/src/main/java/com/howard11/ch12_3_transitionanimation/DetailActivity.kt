package com.howard11.ch12_3_transitionanimation

import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {
    private val images = intArrayOf(R.drawable.image1,
        R.drawable.image2,
    R.drawable.image3)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.detail_activity)

        val fruitImage = findViewById<ImageView>(R.id.fruitImage)
        val fruitTxt =  findViewById<TextView>(R.id.fruitTxt)
        //轉型
        val type =  intent.getSerializableExtra("type") as Fruit

        val infos = resources.getStringArray(R.array.detail)
        fruitImage.setImageResource(images[type.ordinal])
        fruitTxt.setText(infos[type.ordinal])
        Log.d("Howard","type:$type")


    }
}