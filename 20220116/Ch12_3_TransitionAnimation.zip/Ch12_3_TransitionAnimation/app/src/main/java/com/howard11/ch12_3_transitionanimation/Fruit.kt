package com.howard11.ch12_3_transitionanimation

enum class Fruit {
    APPLE,
    CHERRY,
    KIWI
}