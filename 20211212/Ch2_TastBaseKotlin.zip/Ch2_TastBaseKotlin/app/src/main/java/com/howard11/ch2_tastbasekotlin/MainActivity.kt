package com.howard11.ch2_tastbasekotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlin.math.log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //test1()
        //test2()
        //test3()
        //test4(9)
//        test5("Ken")
//        test5(25)
        //test5(2.5f)
       // Log.d("Howard",test6(900))
        //Log.d("Howard",test7(900))
        //test8(10)
        //test8(5)
       // test9()
        //test10()
       // test11()
        test12()
    }
    fun test12(){

           bye@ for (i in 1 .. 5){

                 for (k in 1..3){
                     if (i==2) break@bye
                    Log.d("Howard","$i:$k")
                 }
            }

    }

    fun test11(){
        for (i in 1 .. 10){
            if (i == 3) continue
            Log.d("Howard","i:$i")
//            if (i == 3) break
        }
    }

    fun test10(){
        var count = 1
        var end = 10
        while(count < end){
            Log.d("Howard","count:$count")
            count *=2
        }

    }
    fun test9(){
//        for (n in 1..20){
//              Log.d("Howard","n:$n")
//        }
//        Log.d("Howard","==============================")
//        for (n in 1..20 step 2){
//            Log.d("Howard","n:$n")
//        }
//        for (n in 20 downTo 1 step 2){
//                Log.d("Howard","downTo:$n")
//        }

        val len = 5
        for (i in 0 until len){
            Log.d("Howard","len:$i")
        }

    }
    fun test8(month:Int){
        val season = when(month){
                in 3..5 ->"春"
                in 6..8-> "夏"
                in 9..11 ->"秋"
                12,1,2 ->"冬" //非連貫性的
                else ->"火星!"
        }
        Log.d("Howard",season)
    }

    fun test7(age:Int):String{
            return when(age){
                    in 0..17 -> "未成年"
                    in 18..64 -> "成年"
                    in 65..300 -> "老年"
                    else -> "仙人"
            }
    }
    fun test6(age:Int):String{
        //0~18 未成年
        //18~65成年
        //65以上 小於 300老年
        //仙人

    return when{
        age >= 0 && age < 18 ->"未成年"
        age >= 18 && age < 65 ->"成年"
        age >= 65 && age < 300 ->"老年"
        else ->"仙人"
    }

    }
    fun test5(any:Any){
            when(any){
                is String ->{Log.d("Howard","我是字串:$any")}
                is Int->Log.d("Howard","我是整數:$any")
                else ->Log.d("Howard","Error")
            }
    }
    fun test4(action:Int){
            when(action){
                1 ->{Log.d("Howard","Jump")}
                2 ->{Log.d("Howard","Fly")}
                else ->{
                    Log.d("Howard","錯誤!")
                }
            }
    }

    fun test3(){
        val score = 75
       val msg = if (score >= 60){
            Log.d("Howard","Pass")
           "pass:$score"
        }else{
            Log.d("Howard","Fail")
           "fail:$score"
        }
        Log.d("Howard","msg:$msg")

    }

    fun test2(){
        val age:Int = 10
        val name:String = "Ken"
        val msg = "Name:$name Age:$age"
        Log.d("Howard",msg)
        //$字號表示變數
        val v1 = 20
        val v2 = 10
        val msg2 = "ans:$v1/$v2"
        Log.d("Howard",msg2)
        val msg3 = "ans:${v1/v2}"
        Log.d("Howard",msg3)
        // """ 中的所有內容都視為字串
        val filePath = """C:\myfile\value.txt"""
        Log.d("Howard",filePath)

        val context = """A B C 
                         E   F   G
                         H  I  J  K"""
        Log.d("Howard",context)

        val wieght = "71"
        Log.d("Howard","test:${wieght.toInt()+2}")


    }

    //宣告變數
    fun test1(){
        //int value = 10;
        //float value2 = 2.5f;
        var height:Float = 175.3F
        var age:Int = 28
        Log.d("Howard","Height:"+height+" age:"+age)
        //沒事多呼叫常數
        val myConstant = 25
        //myConstant = 10
        Log.d("Howard","myConstant:"+myConstant)
    }
}