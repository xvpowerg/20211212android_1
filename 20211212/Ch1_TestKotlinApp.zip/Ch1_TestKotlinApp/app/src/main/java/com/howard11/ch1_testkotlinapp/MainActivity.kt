package com.howard11.ch1_testkotlinapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var myButton = findViewById<Button>(R.id.btn1)
        myButton.setOnClickListener {
            //Toast.makeText(this,"Howard!",Toast.LENGTH_SHORT).show()
            Log.d("Howard","button down")
        }
    }
}