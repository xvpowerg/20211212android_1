package com.howard11.ch1_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private class MyOnclick  implements OnClickListener {
                public void onClick(View v){
                    Toast.makeText(MainActivity.this,
                            "按下按鈕",Toast.LENGTH_SHORT).show();
                }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       Button btnx1 =  findViewById(R.id.btn1);
        MyOnclick myclock = new MyOnclick();
        btnx1.setOnClickListener(myclock);
    }
}