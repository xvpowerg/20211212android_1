package com.howard11.ch10_2_newresult;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView resultTxtView;

    private ActivityResultLauncher<Intent> bmiLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    (i)->{
                        i.getData();
                       String msg =  i.getData().getStringExtra("bmi_msg");
                        resultTxtView.setText(msg);
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText heightEdTxt =  findViewById(R.id.heightEdtxt);
        EditText weightEdTxt =  findViewById(R.id.weightEdtxt);
        resultTxtView = findViewById(R.id.resultTxt);
        Button btn = findViewById(R.id.submitBtn);
        btn.setOnClickListener(v->{
            String heightStr =   heightEdTxt.getText().toString();
            String  weightEStr =   weightEdTxt.getText().toString();
            Intent toCbaIntent = new Intent(this,CalculateBmiActivity.class);
            toCbaIntent.putExtra("heightStr",heightStr);
            toCbaIntent.putExtra("weightStr",weightEStr);
            bmiLauncher.launch(toCbaIntent);
        });

    }
}