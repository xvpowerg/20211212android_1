package com.howard11.ch10_3_call_out;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText phoneEdit;
    private void callOut(){
        String number = phoneEdit.getText().toString();
        Uri uri =    Uri.parse("tel:"+number);
        Intent phoneNumberIntent = new Intent(Intent.ACTION_CALL,uri);
        startActivity(phoneNumberIntent);
    }

    private boolean checkPermissions(){
        //確認是否已選擇過權限 如果選擇不授權 回傳true
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
        != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CALL_PHONE},
                    100);
        }else{
                return true;
        }

        return false;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        phoneEdit =  findViewById(R.id.phoneEdTxt);
       Button btn =   findViewById(R.id.calloutBtn);

        btn.setOnClickListener(v->{
            if (checkPermissions()){
                callOut();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    callOut();
        }
    }
}