package com.howard11.ch9_parcelable1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.howard11.ch9_parcelable1.beans.ProductInfo;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button submitBtn = findViewById(R.id.submitBtn);
        EditText pNameEd = findViewById(R.id.pNameEdtxt);
        EditText locEd =  findViewById(R.id.locEdtxt);
        EditText priceEd =   findViewById(R.id.priceEdtxt);
        submitBtn.setOnClickListener(v->{
            Intent toDetail = new Intent(this,DetailActivity.class);
            String pName = pNameEd.getText().toString();
            String loc = locEd.getText().toString();
            String priceStr = priceEd.getText().toString();

            ProductInfo productInfo =
                    new ProductInfo(pName,loc,Float.parseFloat(priceStr));
//            toDetail.putExtra("pName",pNameEd.getText().toString());
//            toDetail.putExtra("loc",locEd.getText().toString());
//            toDetail.putExtra("price",priceEd.getText().toString());
            toDetail.putExtra("productInfo",productInfo);
            startActivity(toDetail);
        });
    }
}