package com.howard11.ch9_parcelable1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.howard11.ch9_parcelable1.beans.ProductInfo;

public class DetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_layout);
        TextView pNameTxt =  findViewById(R.id.pNameTxt);
        TextView locTxt =  findViewById(R.id.locTxt);
        TextView priceTxt = findViewById(R.id.priceTxt);
        Intent data = getIntent();
        ProductInfo pInfo =  data.getParcelableExtra("productInfo");
//        String pName=  data.getStringExtra("pName");
//        String loc = data.getStringExtra("loc");
//        String price = data.getStringExtra("price");

        String pName=  pInfo.getName();
        String loc = pInfo.getLoc();
        String price = pInfo.getPrice()+"";

        pNameTxt.setText(pName);
        locTxt.setText(loc);
        priceTxt.setText(price);
        //把MainActivity 寫入 Intent的數值取出
        //並顯示於 UI

    }
}
