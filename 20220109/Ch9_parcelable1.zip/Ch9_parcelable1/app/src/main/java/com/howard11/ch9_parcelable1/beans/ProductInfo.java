package com.howard11.ch9_parcelable1.beans;


import android.os.Parcel;
import android.os.Parcelable;

public class ProductInfo implements Parcelable {
    private String name;
    private String loc;
    private float price;

    public ProductInfo(){}
    //反序列化 把序列化的東西轉為物件
    private ProductInfo(Parcel in){
        name = in.readString();
        loc = in.readString();
        price = in.readFloat();
    }
    @Override
    public int describeContents() {
        return 0;
    }
    //序列化 順序必須跟read一樣
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(loc);
        dest.writeFloat(price);
    }

    public ProductInfo(String name, String loc, float price) {
        this.name = name;
        this.loc = loc;
        this.price = price;
    }
    //CREATOR 幫助方序列化 反序列化
    public static final Parcelable.Creator<ProductInfo> CREATOR =
            new Parcelable.Creator<ProductInfo>(){
                @Override
                public ProductInfo createFromParcel(Parcel source) {
                    return new ProductInfo(source);
                }

                @Override
                public ProductInfo[] newArray(int size) {
                    return new ProductInfo[size];
                }
            };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLoc() {
        return loc;
    }

    public void setLoc(String loc) {
        this.loc = loc;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "ProductInfo{" +
                "name='" + name + '\'' +
                ", loc='" + loc + '\'' +
                ", price=" + price +
                '}';
    }
}
