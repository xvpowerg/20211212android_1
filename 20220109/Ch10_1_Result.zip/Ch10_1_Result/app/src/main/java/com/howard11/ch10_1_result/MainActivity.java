package com.howard11.ch10_1_result;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
   private  TextView resultTxtView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText heightEdTxt =  findViewById(R.id.heightEdtxt);
        EditText weightEdTxt =  findViewById(R.id.weightEdtxt);
        resultTxtView = findViewById(R.id.resultTxt);
        Button btn = findViewById(R.id.submitBtn);
        btn.setOnClickListener(v->{

           String heightStr =   heightEdTxt.getText().toString();
           String  weightEStr =   weightEdTxt.getText().toString();
           Intent toCbaIntent = new Intent(this,CalculateBmiActivity.class);
            toCbaIntent.putExtra("heightStr",heightStr);
            toCbaIntent.putExtra("weightStr",weightEStr);
            startActivityForResult(toCbaIntent,500);

        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK){ return;}
        if (requestCode == 500){
            String bmimsg = data.getStringExtra("bmi_msg");
            resultTxtView.setText(bmimsg);
        }

    }
}