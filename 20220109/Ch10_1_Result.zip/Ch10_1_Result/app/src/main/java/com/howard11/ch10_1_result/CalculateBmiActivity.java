package com.howard11.ch10_1_result;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CalculateBmiActivity  extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bmi_calculate_layout);
            Intent data = getIntent();
            String heightStr = data.getStringExtra("heightStr");
            String weightStr = data.getStringExtra("weightStr");

            Button bmiCaluBtn = findViewById(R.id.caluBtn);
            TextView heightText = findViewById(R.id.heightTxt);
            TextView weightTxt =  findViewById(R.id.weightTxt);

            heightText.setText(heightStr+"cm");
            weightTxt.setText(weightStr+"kg");


        bmiCaluBtn.setOnClickListener(v->{
                float height = Float.parseFloat(heightStr);
                float weight = Float.parseFloat(weightStr);
                height/= 100;
                double bmi = weight / Math.pow(height,2);
                String bmiMsg =   String.format("%.3f",bmi);
                Intent newData = new Intent();
                newData.putExtra("bmi_msg",bmiMsg);
                setResult(RESULT_OK,newData);
                finish();
        });
    }
}
