package com.howard11.ch13_2__test_layout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    private int index = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int[] images = {R.drawable.image1,R.drawable.image2};

        setContentView(R.layout.test10_testall_layout);
        FloatingActionButton fb =   findViewById(R.id.changeFruitBtn);
        ImageView fruitImageView =  findViewById(R.id.fruitImageView);
        fb.setOnClickListener(v->{
            fruitImageView.setImageResource(images[index++]);
            index %= 2;
        });
    }
}