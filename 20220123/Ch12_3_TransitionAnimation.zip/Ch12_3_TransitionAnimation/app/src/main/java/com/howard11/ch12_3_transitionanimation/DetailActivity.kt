package com.howard11.ch12_3_transitionanimation

import android.os.Bundle
import android.transition.Explode
import android.transition.Fade
import android.transition.Slide
import android.util.Log
import android.view.Window
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {
    private val images = intArrayOf(R.drawable.image1,
        R.drawable.image2,
    R.drawable.image3)
    //設定動畫的參數
    private fun setupTrains(){
      window.requestFeature(Window.FEATURE_CONTENT_TRANSITIONS)
        val flag =
            intent.getStringExtra(getString(R.string.tr_intent_flag))

        when(flag){
           getString(R.string.tr_explode)->{
                val extr = Explode()
               extr.duration = 1000
               window.exitTransition =extr
               window.exitTransition = extr

           }

            getString(R.string.tr_slide)->{
                val slideTra = Slide()
                slideTra.duration = 1000
                window.enterTransition =slideTra
                window.exitTransition =slideTra
            }

            getString(R.string.tr_fade)->{
                val fadeTr = Fade()
                fadeTr.duration = 1000
                window.enterTransition = fadeTr
                window.exitTransition = fadeTr
            }


        }

    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //動畫設定要早於setContentView
        setupTrains()
        setContentView(R.layout.detail_activity)

        val fruitImage = findViewById<ImageView>(R.id.fruitImage)
        val fruitTxt =  findViewById<TextView>(R.id.fruitTxt)
        //轉型
        val type =  intent.getSerializableExtra("type") as Fruit

        val infos = resources.getStringArray(R.array.detail)
        fruitImage.setImageResource(images[type.ordinal])
        fruitTxt.setText(infos[type.ordinal])
        Log.d("Howard","type:$type")


    }
}