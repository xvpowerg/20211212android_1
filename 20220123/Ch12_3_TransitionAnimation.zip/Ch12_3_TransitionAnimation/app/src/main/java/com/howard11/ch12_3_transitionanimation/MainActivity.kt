package com.howard11.ch12_3_transitionanimation

import android.app.ActivityOptions
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Pair
import android.view.View
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {

        private fun showDetail(btn: View, type:Fruit,
                               trans:String=getString(R.string.tr_explode)){
            val totDetail = Intent(this,DetailActivity::class.java)
            totDetail.putExtra("type",type)
            totDetail.putExtra(getString(R.string.tr_intent_flag),trans)
            val title = findViewById<ImageView>(R.id.titleImage) as View
            val p1 = Pair(title, getString(R.string.tran1_name_title))
            val p2 = Pair(btn, getString(R.string.tran2_name_btn))
            val tran = ActivityOptions.makeSceneTransitionAnimation(this,p1,p2)
            startActivity(totDetail,tran.toBundle())
        }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val f1Btn =  findViewById<Button>(R.id.f1Btn)
        val f2Btn = findViewById<Button>(R.id.f2Btn)
        val f3Btn = findViewById<Button>(R.id.f3Btn)

        f1Btn.setOnClickListener {
            showDetail(it,Fruit.APPLE)
        }
        f2Btn.setOnClickListener {
            showDetail(it,Fruit.CHERRY,getString(R.string.tr_slide))
        }
        f3Btn.setOnClickListener {
            showDetail(it,Fruit.KIWI,getString(R.string.tr_fade))
        }
    }
}