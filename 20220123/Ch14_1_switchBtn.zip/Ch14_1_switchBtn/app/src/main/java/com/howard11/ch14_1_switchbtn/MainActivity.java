package com.howard11.ch14_1_switchbtn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView imageView1 = findViewById(R.id.imageView);
        ImageView imageView2 = findViewById(R.id.imageView2);
        ToggleButton toggleButton =  findViewById(R.id.toggleButton);
        toggleButton.setChecked(true);

        Switch sw1 = findViewById(R.id.switch1);
        sw1.setChecked(true);

        toggleButton.setOnCheckedChangeListener((v,isChecked)->{

            Log.d("Howard","isChecked:"+isChecked);
            if (isChecked){
                imageView1.setVisibility(View.VISIBLE);
            }else{
                imageView1.setVisibility(View.INVISIBLE);
            }


        });

        sw1.setOnCheckedChangeListener((v,isChecked)->{
            Log.d("Howard","Switch isChecked:"+isChecked);
            if (isChecked){
                imageView2.setVisibility(View.VISIBLE);
            }else{
                imageView2.setVisibility(View.GONE);
            }


        });
    }
};