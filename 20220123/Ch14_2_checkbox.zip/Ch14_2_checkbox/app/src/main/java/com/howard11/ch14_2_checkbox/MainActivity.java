package com.howard11.ch14_2_checkbox;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CheckBox;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CheckBox box1 = findViewById(R.id.item1Cbox);
        CheckBox box2 = findViewById(R.id.item2Cbox);
        CheckBox box3 = findViewById(R.id.item3Cbox);
        CheckBox[] checkBoxes = {box1,box2,box3};
        Button btn = findViewById(R.id.submitBtn);
        btn.setOnClickListener(v->{
                for (CheckBox box : checkBoxes){
                        if (box.isChecked()){
                            Log.d("Howard","msg:"+box.getText());
                        }else{
                            Log.d("Howard","Cancel msg:"+box.getText());
                        }
                }
        });

    }
}