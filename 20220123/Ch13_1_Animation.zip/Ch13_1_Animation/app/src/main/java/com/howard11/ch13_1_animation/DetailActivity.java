package com.howard11.ch13_1_animation;

import android.content.Intent;
import android.os.Bundle;
import android.transition.Explode;
import android.transition.Fade;
import android.transition.Slide;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    private int[] images = {R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3};

    private void setupAnim(){
        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
       String flag =
               getIntent().getStringExtra(getString(R.string.tr_intent_flag));
            if (flag.equals(getString(R.string.tr_explode))){
                Explode explode = new Explode();
                explode.setDuration(1000);
                getWindow().setEnterTransition(explode);
                getWindow().setExitTransition(explode);
            }else if(flag.equals(getString(R.string.tr_fade))){
                Fade fade = new Fade();
                fade.setDuration(1000);
                getWindow().setEnterTransition(fade);
                getWindow().setExitTransition(fade);
            }else if(flag.equals(getString(R.string.tr_slide))){
                Slide slide = new Slide();
                slide.setDuration(1000);
                getWindow().setEnterTransition(slide);
                getWindow().setExitTransition(slide);
            }
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupAnim();
        setContentView(R.layout.detail_activity);
        String[] infos = getResources().getStringArray(R.array.detail);
        Intent data = getIntent();
        Fruit fruit = (Fruit) data.getSerializableExtra("type");

        ImageView  fruitImage =  findViewById(R.id.fruitImage);
        TextView  fruitTxt =   findViewById(R.id.fruitTxt);

        fruitImage.setImageResource(images[fruit.ordinal()]);
        fruitTxt.setText(infos[fruit.ordinal()]);
    }
}
