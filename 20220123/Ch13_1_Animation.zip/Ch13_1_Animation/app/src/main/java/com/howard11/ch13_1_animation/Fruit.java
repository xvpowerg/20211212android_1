package com.howard11.ch13_1_animation;

public enum Fruit {
    APPLE,
    CHERRY,
    KIWI
}
