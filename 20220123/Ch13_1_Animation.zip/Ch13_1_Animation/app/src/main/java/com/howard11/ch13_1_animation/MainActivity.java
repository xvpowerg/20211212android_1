package com.howard11.ch13_1_animation;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private void showDetail(View view){
        Intent toDetail = new Intent(this,DetailActivity.class);
            Fruit type = Fruit.APPLE;
            String trans = getString(R.string.tr_explode);

            View titleView = findViewById(R.id.titleImage);

            switch(view.getId()){
                case R.id.f1Btn:
                    type = Fruit.APPLE;
                    trans = getString(R.string.tr_explode);
                    break;
                case R.id.f2Btn:
                    type = Fruit.CHERRY;
                    trans = getString(R.string.tr_slide);
                    break;
                case R.id.f3Btn:
                    type = Fruit.KIWI;
                    trans = getString(R.string.tr_fade);
                    break;
            }

        Pair<View,String> p1 = new Pair<>(titleView,
                                    getString(R.string.tran1_name_title));
        Pair<View,String> p2 = new Pair<>(view,
                                  getString(R.string.tran2_name_btn));
        ActivityOptions aop=   ActivityOptions.makeSceneTransitionAnimation(this,p1,p2);
            toDetail.putExtra("type",type);
            toDetail.putExtra(getString(R.string.tr_intent_flag),trans);
            startActivity(toDetail,aop.toBundle());
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1 = findViewById(R.id.f1Btn);
        Button btn2 = findViewById(R.id.f2Btn);
        Button btn3 =findViewById(R.id.f3Btn);
        btn1.setOnClickListener(this::showDetail);
        btn2.setOnClickListener(this::showDetail);
        btn3.setOnClickListener(this::showDetail);
    }
}