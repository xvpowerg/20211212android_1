package com.howard11.test_listview1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<String> list = new ArrayList<>();
        list.add("Ken");
        list.add("Vivin");
        list.add("Lindy");
        list.add("Joy");
        ListView listView =  findViewById(R.id.listview);
//        ArrayAdapter<String> arrayAdapter =
//                new ArrayAdapter(this,
//                        android.R.layout.simple_list_item_1,
//                        android.R.id.text1,list);
//        listView.setAdapter(arrayAdapter);
        ArrayAdapter<String> adapter = new ArrayAdapter(this,
                R.layout.array_adapter_layout,R.id.itemTxt,list);
        listView.setAdapter(adapter);

    }
}
