package com.howard11.test_listview2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        List<Map<String,Object>> list = new ArrayList<>();
        String key1 = "name";
        String key2 = "image";

        Map<String,Object> data1 = new HashMap<>();
        data1.put(key1,"蘋果");
        data1.put(key2,R.drawable.image1);
        Map<String,Object> data2 = new HashMap<>();
        data2.put(key1,"櫻桃");
        data2.put(key2,R.drawable.image2);
        Map<String,Object> data3 = new HashMap<>();
        data3.put(key1,"奇異果");
        data3.put(key2,R.drawable.image3);

        list.add(data1);
        list.add(data2);
        list.add(data3);

        ListView fList = findViewById(R.id.fruitList);
        String[] from = {key1,key2};
        int[] to = {R.id.fname_txt,R.id.fruit_image};
        SimpleAdapter simpleAdapter = new SimpleAdapter(this,list,
                R.layout.simple_adapter_layout,from,to);
        fList.setAdapter(simpleAdapter);
        fList.setOnItemClickListener((parent,v,post,id)->{
            Log.d("Howard","post:"+post);
            String msg = list.get(post).get(key1).toString();
            Log.d("Howard","msg:"+msg);
        });


    }
}