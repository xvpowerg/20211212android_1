package com.howard11.test_sprinner2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Optional;

public class MainActivity extends AppCompatActivity {
    private ArrayList<String[]> countryList = new ArrayList<>();
    private Spinner countrySp ;
    private void initCountry(){
        Resources res = getResources();
        countryList.add(res.getStringArray(R.array.country_0));
        countryList.add(res.getStringArray(R.array.country_1));
        countryList.add(res.getStringArray(R.array.country_2));
    }
    private void plan1(int position){
            String[] countryArray = countryList.get(position);
            ArrayAdapter<String> contryAd = new ArrayAdapter(this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    countryArray);
        countrySp.setAdapter(contryAd);
    }
    //取得舊的ArrayAdapter
    private void plan2(int position){
        String[] countryArray = countryList.get(position);
     ArrayAdapter<String> countryAd =
             (ArrayAdapter)countrySp.getAdapter();
        Optional<ArrayAdapter<String>> arrayAdapterOp = Optional.ofNullable(countryAd);
        //沒有Adapter建立
        //有舊的Adapter使用之前的
        countryAd = arrayAdapterOp.orElseGet(()->{
                ArrayAdapter<String> newArrayAdap = new ArrayAdapter<>(this,
                        android.R.layout.simple_list_item_1,
                        android.R.id.text1);
                countrySp.setAdapter(newArrayAdap);
            return newArrayAdap;
        });
        countryAd.clear();
        countryAd.addAll(countryArray);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initCountry();
        String[] citiesArray = getResources().getStringArray(R.array.cities);
       Spinner citySpinner =  findViewById(R.id.cities_sp);
        countrySp = findViewById(R.id.country_sp);
        ArrayAdapter<String> cityAdapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,citiesArray);
        citySpinner.setAdapter(cityAdapter);
        TextView cityNameTxt =  findViewById(R.id.city_name_txt);
        citySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d("Howard","position:"+position);
                String cityName = citiesArray[position];
                cityNameTxt.setText(cityName);
                //plan1(position);
                plan2(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}