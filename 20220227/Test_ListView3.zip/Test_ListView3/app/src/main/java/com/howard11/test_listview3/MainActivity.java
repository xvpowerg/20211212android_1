package com.howard11.test_listview3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.howard11.test_listview3.adapter.MyBaseAdapter;
import com.howard11.test_listview3.bean.Student;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ArrayList<Student> list = new ArrayList<>();
        Student st1 = new Student("100","Ken",78,
                "408 臺中市南屯區向學路11號","04-8825252");
        Student st2 = new Student("101","Vivin",93,
                "907 屏東縣鹽埔鄉永樂路33號","097755122");
        Student st3 = new Student("102","Lucy",85,
                "831 高雄市大寮區正忠街13號","07-5521818");
        list.add(st1);
        list.add(st2);
        list.add(st3);
        list.add(st1);
        list.add(st2);
        list.add(st3);
        list.add(st1);
        list.add(st2);
        list.add(st3);

        ListView listView =  findViewById(R.id.stList);
        MyBaseAdapter myBaseAdapter =
                new MyBaseAdapter(list);
        listView.setAdapter(myBaseAdapter);

    }
}