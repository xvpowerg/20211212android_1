package com.howard11.test_listview3.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.howard11.test_listview3.R;
import com.howard11.test_listview3.bean.Student;

import java.util.ArrayList;

public class MyBaseAdapter extends BaseAdapter {
    private ArrayList<Student> dataList;
    public MyBaseAdapter(ArrayList<Student> dataList){
        this.dataList = dataList;
    }
    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Student getItem(int position) {
        return dataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return Integer.parseInt(dataList.get(position).getId());
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Student st = getItem(position);
        View layout = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.st_base_adapter_layout,
                parent,
                false);
        TextView idTxt = layout.findViewById(R.id.idTxt);
        TextView nameTxt = layout.findViewById(R.id.nameTxt);
        idTxt.setText(st.getId());
        nameTxt.setText(st.getName());
        return layout;
    }

}
