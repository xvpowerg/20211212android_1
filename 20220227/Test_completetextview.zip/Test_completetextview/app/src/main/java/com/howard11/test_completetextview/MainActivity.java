package com.howard11.test_completetextview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private String[] imagesStr = new String[4];
    private final String image = "image";
    private void initArray(){

        for (int i = 1; i <= imagesStr.length;i++){
            imagesStr[i-1] = image+i;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initArray();
       AutoCompleteTextView auct =  findViewById(R.id.imageCT);
       ImageView fruitImage = findViewById(R.id.fruitimageView);
        ArrayAdapter<String> adpater = new ArrayAdapter(this,
                android.R.layout.simple_dropdown_item_1line,
                android.R.id.text1,imagesStr);
        auct.setAdapter(adpater);
        //設定多少字元開始提示
        auct.setThreshold(1);
        auct.setOnItemClickListener((par,v,pos,id)->{
            Log.d("Howard","parent:"+par);
            Log.d("Howard","v:"+v);
            Log.d("Howard","pos:"+pos);
            int resid = getResources().getIdentifier(image+(pos+1),
                    "drawable",getPackageName());
            fruitImage.setImageResource(resid);

        });
    }
}