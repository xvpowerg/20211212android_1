package com.howard11.test_my_google_map;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.howard11.test_my_google_map.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    private Marker marker = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
       Button btn1 =  findViewById(R.id.btn1);
       Button btn2 =  findViewById(R.id.btn2);
       Button btn3 = findViewById(R.id.btn3);
        btn3.setOnClickListener(v->{
            //mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            //mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);//地形
            //mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);//衛星地圖
            mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);//衛星地圖 加道路說明


        });


        btn1.setOnClickListener(v->{
                        //24.133703529012983, 120.60985154587215
            LatLng latLng = new LatLng(24.133703529012983,
                    120.60985154587215);
            mMap.animateCamera(
                    CameraUpdateFactory.newLatLngZoom(latLng,17f),
                    2000,null );

        });

        btn2.setOnClickListener(v->{
            MarkerOptions mark = new MarkerOptions();
            MarkerOptions mark2 = new MarkerOptions();
            MarkerOptions mark3 = new MarkerOptions();
            LatLng latLng = new LatLng(24.133703529012983,
                    120.60985154587215);
            LatLng latLng2 = new LatLng(24.13417509549816, 120.6086671351697);
            LatLng latLng3 = new LatLng(24.134605402509862, 120.61040264200385);

           BitmapDescriptor db =  BitmapDescriptorFactory.
                    defaultMarker(BitmapDescriptorFactory.HUE_BLUE);
           BitmapDescriptor food =
                   BitmapDescriptorFactory.fromResource(R.drawable.food);

            mark.title("彩虹卷村");
            mark.position(latLng);

            if (marker == null){
                marker = mMap.addMarker(mark);
            }else{
                marker.remove();
                marker = null;
            }


            mark2.title("棒球場");
            mark2.position(latLng2);
            mark2.icon(db);
            mMap.addMarker(mark2);

            mark3.title("餐廳");
            mark3.position(latLng3);
            mark3.icon(food);
            mMap.addMarker(mark3);
        });

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(24.16246098775883, 120.64034589752498);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        UiSettings uiSet = mMap.getUiSettings();
        uiSet.setZoomControlsEnabled(true);
        uiSet.setTiltGesturesEnabled(true);

    }
}