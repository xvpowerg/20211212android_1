package com.howard11.mask_project.json;

import com.google.gson.Gson;
import com.howard11.mask_project.beans.MaskData;

import java.util.function.Consumer;

public class MaskJsonTools {

    public static void jsonToObject(String maskJson,
                                    Consumer<MaskData> consumer){
        Gson gson = new Gson();
        Thread thread = new Thread(()->{
            MaskData maskData = gson.fromJson(maskJson,MaskData.class);
            consumer.accept(maskData);
        });
        thread.start();
    }
}
