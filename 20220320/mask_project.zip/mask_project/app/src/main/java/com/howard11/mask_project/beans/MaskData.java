package com.howard11.mask_project.beans;

import java.util.ArrayList;

public class MaskData {
        private ArrayList<Feature> features;

    public ArrayList<Feature> getFeatures() {
        return features;
    }

    public void setFeatures(ArrayList<Feature> features) {
        this.features = features;
    }
}
