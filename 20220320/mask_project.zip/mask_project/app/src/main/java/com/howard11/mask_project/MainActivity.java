package com.howard11.mask_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.howard11.mask_project.adapter.MaskAdapter;
import com.howard11.mask_project.json.MaskJsonTools;
import com.howard11.mask_project.net.DownloadMaskJson;


public class MainActivity extends AppCompatActivity {
private ListView maskListView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        maskListView = findViewById(R.id.maskList);

        //maskListView.setAdapter();
    }

    @Override
    protected void onStart() {
        super.onStart();
        DownloadMaskJson downloadMaskJson =
                new DownloadMaskJson(getString(R.string.json_url));
        downloadMaskJson.start(json -> {
            MaskJsonTools.jsonToObject(json,maskData -> {
                MaskAdapter maskAdapter = new MaskAdapter(maskData.getFeatures());
               this.runOnUiThread(()->maskListView.setAdapter(maskAdapter));
            });
        });
    }
}