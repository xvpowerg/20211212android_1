package com.howard11.mask_project.net;

import android.util.Log;

import androidx.annotation.NonNull;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class DownloadMaskJson {
    private String jsonUrl = "";

    public DownloadMaskJson(String jsonUrl){
        this.jsonUrl = jsonUrl;
    }
public interface  DownloadMaskJsonFinish{
        void  callBack(String json);
}
private class OkHttpCallBack implements Callback {
    DownloadMaskJsonFinish jsonFinishCallBack;
    OkHttpCallBack(DownloadMaskJsonFinish jsonFinishCallBack){
            this.jsonFinishCallBack = jsonFinishCallBack;
    }
    @Override
    public void onFailure(@NonNull Call call, @NonNull IOException e) {
        Log.e("Howard","onFailure:"+e);
    }

    @Override
    public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
        String json = response.body().string();
        jsonFinishCallBack.callBack(json);
    }
}
    public void start(DownloadMaskJsonFinish  jsonCallBack){
        OkHttpClient.Builder okb = new OkHttpClient.Builder();
        OkHttpClient client =  okb.retryOnConnectionFailure(true).readTimeout(10,
                TimeUnit.SECONDS).build();
        Request.Builder rb = new Request.Builder();
        Request request = rb.url(jsonUrl).build();
        client.newCall(request).enqueue(new OkHttpCallBack(jsonCallBack));
    }

}
