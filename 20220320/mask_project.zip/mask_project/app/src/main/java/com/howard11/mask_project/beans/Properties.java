package com.howard11.mask_project.beans;

public class Properties {
        private String id;
        private String name;
        private String phone;
        private String address;
        private int mask_adult;
        private  int mask_child;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getMask_adult() {
        return mask_adult;
    }

    public void setMask_adult(int mask_adult) {
        this.mask_adult = mask_adult;
    }

    public int getMask_child() {
        return mask_child;
    }

    public void setMask_child(int mask_child) {
        this.mask_child = mask_child;
    }

    @Override
    public String toString() {
        return "Properties{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", address='" + address + '\'' +
                ", mask_adult=" + mask_adult +
                ", mask_child=" + mask_child +
                '}';
    }
}
