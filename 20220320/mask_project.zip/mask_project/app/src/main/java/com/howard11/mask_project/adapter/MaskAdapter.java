package com.howard11.mask_project.adapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.howard11.mask_project.R;
import com.howard11.mask_project.beans.Feature;

import java.util.List;

public class MaskAdapter extends BaseAdapter {
    private List<Feature> fList;
    public MaskAdapter(List<Feature> fList){
            this.fList = fList;
    }
    @Override
    public int getCount() {
        return fList.size();
    }

    @Override
    public Feature getItem(int position) {
        return fList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).
                inflate(R.layout.mask_adapter_layout,parent,false);

       TextView nameText =  view.findViewById(R.id.nameText);
       TextView phoneText = view.findViewById(R.id.phoneTxt);
       TextView addressText = view.findViewById(R.id.addressTxt);
       TextView adultText = view.findViewById(R.id.adultTxt);
       TextView childText =  view.findViewById(R.id.childTxt);

        Feature f =   getItem(position);
        String name = f.getProperties().getName();
        String phone = f.getProperties().getPhone();
        String address = f.getProperties().getAddress();
        int adultCount = f.getProperties().getMask_adult();
        int childCount = f.getProperties().getMask_child();

        nameText.setText(name);
        phoneText.setText(phone);
        addressText.setText(address);
        adultText.setText("成人:"+adultCount);
        childText.setText("兒童:"+childCount);

        if (adultCount < 100){
            adultText.setTextColor(Color.RED);
        }
        if (childCount < 100){
            childText.setTextColor(Color.RED);
        }
        return view;
    }
}
