package com.howard11.ch7_2_java_stream;

import java.util.Optional;

public class Student {
    private String name;

    public void setName(String name){
        this.name = name;
    }

    public Optional<String> getName(){
        return Optional.ofNullable(this.name) ;
    }

}
