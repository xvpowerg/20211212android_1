package com.howard11.ch7_2_java_stream;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    void testStream(){
        ArrayList<Integer> list = new ArrayList<>();
        list.add(10);
        list.add(5);
        list.add(12);
        list.add(7);
        list.add(9);
        list.stream().filter(v->v>7).
                forEach(s->Log.d("Howard","s:"+s));
//        for (int v : list){
//            if (v > 7)
//            Log.d("Howard","v:"+v);
//        }

    }

    void testOptional(){
        Student st = new Student();
        st.setName(null);
        //isPresent() 內容不是null
//        if (!st.getName().isPresent() ||
//                st.getName().get().length() < 2){
//            Log.d("Howard","error!!");
//        }
        st.getName().ifPresent(
                (String v)->{
                    if(v.length() < 2) Log.d("Howard","Error!");
                });
        String v = st.getName().orElse("Error!");
          Log.d("Howard","v:"+v);
//        if ( st.getName().length() < 2){
//            Log.d("Howard","error!!");
//        }
    }
    void testStream2(){
        ArrayList<Integer> list = new ArrayList<>();
        list.add(10);
        list.add(5);
        list.add(12);
        list.add(7);
        list.add(9);
        if (list.stream().findFirst().isPresent()){
            int v1 = list.stream().findFirst().get();
            Log.d("Howard","v1:"+v1);
        }

    }

    void testStream3(){
        ArrayList<String> list = new ArrayList<>();
        list.add("ken");
        list.add("vivin");
        list.add("lucy");
        list.add("iris");
        list.add("joy");
        //轉換
        list.stream().map(v->v.toUpperCase()).
                forEach(n->Log.d("Howard",n));
        list.stream().map(v->v.length()).
                forEach((Integer len)->Log.d("Howard",len+""));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //testStream();
        //testOptional();
        //testStream2();
        testStream3();
    }
}
