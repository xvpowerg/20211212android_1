package com.howard11.ch7_20220228_1_java_collection;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeSet;

public class MainActivity extends AppCompatActivity {

    void testSet(){
        HashSet<String> nameSet = new HashSet<>();
        nameSet.add("Ken");
        nameSet.add("Vivin");
        nameSet.add("Lindy");
        nameSet.add("Ken");
        nameSet.forEach(v-> Log.d("Howard","v:"+v));
    }

    void testTreeSet(){
        TreeSet<Integer> treeSet = new TreeSet();
        treeSet.add(5);
        treeSet.add(2);
        treeSet.add(6);
        treeSet.add(1);
        treeSet.add(3);
        //小到大排序
        treeSet.forEach(v->Log.d("Howard","v:"+v));
    }
    private class MyComparator implements Comparator<Item> {
            //i1 > i2 回傳正數
            //i1 < i2 回傳負數
            //i1 == i2 回傳0
            public int compare(Item i1,Item i2){
                if (i1.getScore() > i2.getScore()){
                    return 1;
                }else if(i1.getScore() < i2.getScore()){
                    return -1;
                }
                return 0;
            }
    }
    void testTreeSetItem(){
        Item item1 = new Item("Ken",81);
        Item item2 = new Item("Vivin",95);
        Item item3 = new Item("Lucy",83);
        Item item4 = new Item("Iris",71);
        MyComparator myComparator = new MyComparator();
        //TreeSet<Item> treeSet = new TreeSet(myComparator);
        Comparator<Item> cmp =
                Comparator.comparing(v->v.getScore());
        cmp = cmp.reversed();
        TreeSet<Item> treeSet = new TreeSet(cmp);
        treeSet.add(item1);
        treeSet.add(item2);
        treeSet.add(item3);
        treeSet.add(item4);
        treeSet.forEach(v->Log.d("Howard","v:"+v));
    }

    void testMpa(){
        //Key Value
        HashMap<String,Integer> map = new HashMap();
        map.put("Ken",100);
        map.put("Vivin",78);
        map.put("Lucy",82);
        map.put("Iris",95);
        int v = map.get("Lucy");
        Log.d("Howard","value:"+v);
        map.forEach((k,v2)->Log.d("Howard",k+":"+v2));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // testSet();
        //testTreeSet();
//        Item item1 = new Item("Ken",56);
//        Log.d("Howard","item1:"+item1);
        //testTreeSetItem();
        testMpa();
    }
}
