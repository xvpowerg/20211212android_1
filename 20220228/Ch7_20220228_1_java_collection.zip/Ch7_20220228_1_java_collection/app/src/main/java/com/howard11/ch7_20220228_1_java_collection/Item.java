package com.howard11.ch7_20220228_1_java_collection;

public class Item {
    private String name;
    private int score;
    public Item(String name,int score){
        this.name = name;
        this.score = score;
    }
    public String getName(){
        return name;
    }
    public int getScore(){
        return score;
    }
    public String toString(){
        return name+":"+score;
    }

}
