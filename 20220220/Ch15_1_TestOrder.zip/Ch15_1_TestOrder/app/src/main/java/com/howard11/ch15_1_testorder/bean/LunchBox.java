package com.howard11.ch15_1_testorder.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class LunchBox  implements Parcelable {
    private List<Item> items = new ArrayList<>();
    private OrderTackStatus status = OrderTackStatus.OUT;
    public enum OrderTackStatus{
        OUT,
        IN
    }
    public static final Parcelable.Creator<LunchBox> CREATOR = new Creator<LunchBox>() {
        @Override
        public LunchBox createFromParcel(Parcel source) {
            return new LunchBox(source);
        }

        @Override
        public LunchBox[] newArray(int size) {
            return new LunchBox[size];
        }
    };
    public LunchBox(){

    }
    private LunchBox(Parcel dest){
        dest.readList(items,Item.class.getClassLoader());
        int enumType = dest.readInt();
        status =
                enumType == OrderTackStatus.OUT.ordinal()?OrderTackStatus.OUT:OrderTackStatus.IN;
    }


    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeList(items);
        dest.writeInt(status.ordinal());
    }

    @Override
    public int describeContents() {
        return 0;
    }


    public void appendItem(Item item){
        items.add(item);
    }
    public void setStatus(OrderTackStatus status){
        this.status = status;
    }
    public OrderTackStatus getStatus(){
            return status;
    }
    private List<Item> getItems(){
        return items;
    }
    public void forEachItem(Consumer<Item> items){
        for (Item it : getItems()){
            items.accept(it);
        }
    }

    public int total(){
        int total = 0;
        for(Item it :getItems() ){
            total +=it.getCount() * it.getPrice();
        }
        return total;
    }

}
