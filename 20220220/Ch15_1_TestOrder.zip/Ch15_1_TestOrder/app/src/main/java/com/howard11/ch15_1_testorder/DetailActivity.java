package com.howard11.ch15_1_testorder;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.howard11.ch15_1_testorder.bean.LunchBox;

public class DetailActivity  extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_layout);
    LunchBox lunchBox =  getIntent().getParcelableExtra("lunchBox");
    Log.d("Howard","lunchBox:"+lunchBox);
    StringBuilder sb = new StringBuilder();
        lunchBox.forEachItem(it->{
            sb.append(String.format("品名:%s金額:%d數量:%d\n",
                    it.getName(),it.getPrice(),it.getCount()));
        });
        sb.append("總金額:"+lunchBox.total());
        TextView detailMsg =  findViewById(R.id.detailMsgTxt);
        detailMsg.setText(sb.toString());
    //"品名: 金額: 數量: "
   // "品名: 金額: 數量: "
   //總金額:


//        lunchBox.forEachItem(it->{
//            Log.d("Howard","itm:"+it);});


    }
}
