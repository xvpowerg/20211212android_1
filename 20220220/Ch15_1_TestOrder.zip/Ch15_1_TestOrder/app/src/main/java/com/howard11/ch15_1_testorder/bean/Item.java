package com.howard11.ch15_1_testorder.bean;

import android.os.Parcel;
import android.os.Parcelable;

/*
 作者:howard
 功能:產品的基本資料
 */
public class Item implements Parcelable {
    private String name;
    private int price;
    private int count;

    public Item() {

    }
    private Item(Parcel parcel){
        name = parcel.readString();
        price = parcel.readInt();
        count =  parcel.readInt();
    }

    public static final Parcelable.Creator<Item> CREATOR = new Parcelable.Creator<Item>(){
        @Override
        public Item createFromParcel(Parcel source) {
            return new Item(source);
        }
        @Override
        public Item[] newArray(int size) {
            return new Item[size];
        }
    };
    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(name);
        parcel.writeInt(price);
        parcel.writeInt(count);
    }

    @Override
    public int describeContents() {
        return 0;
    }


    public Item(String name, int price, int count) {
        this.name = name;
        this.price = price;
        this.count = count;
    }

    public String getName() {
        return name;
    }

//    public void setName(String name) {
//        this.name = name;
//    }

    public int getPrice() {
        return price;
    }

//    public void setPrice(int price) {
//        this.price = price;
//    }

    public int getCount() {
        return count;
    }

//    public void setCount(int count) {
//        this.count = count;
//    }

    @Override
    public String toString() {
        return "Item{" +
                "name='" + name + '\'' +
                ", price=" + price +
                ", count=" + count +
                '}';
    }
}
