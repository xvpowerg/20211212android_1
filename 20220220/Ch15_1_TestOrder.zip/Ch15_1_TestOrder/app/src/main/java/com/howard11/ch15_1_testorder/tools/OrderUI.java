package com.howard11.ch15_1_testorder.tools;

import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

import com.howard11.ch15_1_testorder.R;
import com.howard11.ch15_1_testorder.bean.Item;
import com.howard11.ch15_1_testorder.bean.LunchBox;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;

public class OrderUI {
    private List<CheckBox> itemCheckBoxList = new ArrayList<>();
    private List<EditText> countEditTextList = new ArrayList<>();
    private int[] prices = {100,70,90};
    private Map<Integer, RadioButton> radioButtonMapMap = new HashMap<>();
    private int countMax = 10000;
    private List<String> verifyMsgList = new ArrayList<>();
    private boolean selectItemCheckBox = false;
    private LunchBox.OrderTackStatus tackStatus =  LunchBox.OrderTackStatus.OUT;
    private VerifyMsgEvent verifyMsgevent = null;
//    public String getSelectedOrder(){
//        return "";
//    }

    public void appendItemCheckBox(CheckBox... checkboxs){
        for (CheckBox cb : checkboxs){
            itemCheckBoxList.add(cb);
        }

    }
    public void appendTakeRadioButton(RadioButton... radioButtons){
        for (RadioButton rb : radioButtons){
            radioButtonMapMap.put(rb.getId(),rb);
        }
    }

    public void appendCountEditText(EditText... editTexts){
        for (EditText editText : editTexts){
            countEditTextList.add(editText);
        }
    }

    private void loopIsCheckedCBList(BiConsumer<Integer,CheckBox> func){
        loopIsCheckedCBList((i,v)->{
                    func.accept(i,v);
                    return true;
                },
                null,
                null);
    }

    private void loopIsCheckedCBList(BiFunction<Integer,CheckBox, Boolean> func,
                                     Consumer<CheckBox> passAction,
                                     Consumer<CheckBox> failAction){
        selectItemCheckBox = false;
        for(int index = 0; index <itemCheckBoxList.size() ; index++){
            CheckBox checkBox = itemCheckBoxList.get(index);
            if (checkBox.isChecked()) {
                selectItemCheckBox = true;
               boolean pass =  func.apply(index,checkBox);
               if (passAction != null && pass){
                   passAction.accept(checkBox);
               }else if(failAction!= null && !pass){
                   failAction.accept(checkBox);
               }
            }
        }
    }

    public boolean verifyData(){
        verifyMsgList.clear();
        loopIsCheckedCBList((index,checkBox) ->{
           EditText editText = countEditTextList.get(index);
            String countStr =  editText.getText().toString().trim();
            if (countStr.isEmpty() || Integer.parseInt(countStr) == 0 ||
                    Integer.parseInt(countStr) > countMax){
                return false;
            }
            return true;
        },null,checkBox -> {
            verifyMsgList.add(checkBox.getText().toString()+"數量錯誤");
        } );

            if (!selectItemCheckBox){
                verifyMsgList.add("請選擇某產品");
            }
            //觸發verifyMsgList 的事件
        triggerVerifyMsgEvent();
    //假設verifyMsgList 有訊息表示有錯誤 驗證無法通過
        return verifyMsgList.size() == 0;
    }


    private  void radioToOrderTackStatus(){

        radioButtonMapMap.forEach((k,v)->{
                if (v.isChecked() && k == R.id.takeRB2){
                    tackStatus = LunchBox.OrderTackStatus.IN;
                }else{
                    tackStatus = LunchBox.OrderTackStatus.OUT;
                }
        });
    }
    private void appendItemToLunchBox(LunchBox lunchBox){
        //有勾選的才會呼叫
        loopIsCheckedCBList((index,checkBox) ->{
            int price = prices[index];
            EditText countEdit = countEditTextList.get(index);
            int count = Integer.parseInt(countEdit.getText().toString());
            String name = checkBox.getText().toString();
            Item p = new Item(name,price,count);
            lunchBox.appendItem(p);
                });
        //
    }

    public void submitData(Consumer<LunchBox> action){
        LunchBox lunchBox = new LunchBox();
        radioToOrderTackStatus();
        lunchBox.setStatus(tackStatus);
        //寫入Lunch的Item
        appendItemToLunchBox(lunchBox);
        action.accept(lunchBox);
    }

    public  interface  VerifyMsgEvent{

        void  action(List<String> list);

    }

    private void triggerVerifyMsgEvent(){
        if (verifyMsgevent != null && verifyMsgList.size() > 0)
            verifyMsgevent.action(verifyMsgList);
    }
    public void registerVerifyMsgEvent(VerifyMsgEvent event){
        verifyMsgevent = event;

    }


}
