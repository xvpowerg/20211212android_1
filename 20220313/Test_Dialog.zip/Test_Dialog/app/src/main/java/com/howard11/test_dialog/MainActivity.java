package com.howard11.test_dialog;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class MainActivity extends AppCompatActivity {
private int selectedStatus = 0;

    private void dialogBtn(DialogInterface dialon,int which){
            String msg = "";
            switch(which){
                case DialogInterface.BUTTON_POSITIVE:
                    msg = "確定";
                    break;
                case  DialogInterface.BUTTON_NEGATIVE:
                    msg = "取消";
                    break;
                case  DialogInterface.BUTTON_NEUTRAL:
                    msg = "關於我";
                    break;
            }
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn4 = findViewById(R.id.btn4);
        Button btn5 = findViewById(R.id.btn5);
        Button btn6 = findViewById(R.id.btn6);
//        DialogInterface.OnClickListener onClick1=  new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                Toast.makeText(MainActivity.this,"確定",Toast.LENGTH_SHORT).show();
//            }
//        };
//        DialogInterface.OnClickListener onClick2 = new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                Toast.makeText(MainActivity.this, "取消", Toast.LENGTH_SHORT).show();
//            }
//        };
        btn1.setOnClickListener(v->{
            new AlertDialog.Builder(this).
                    setTitle("Titile").setMessage("Message").
                    setPositiveButton("確定", this::dialogBtn).
                    setNegativeButton("取消",this::dialogBtn).
                    setNeutralButton("關於我",this::dialogBtn).setCancelable(false).show();

        });

        btn2.setOnClickListener(v -> {
            EditText edit = new EditText(this);
            edit.setInputType(EditorInfo.TYPE_CLASS_NUMBER);
            edit.setHint("請輸入數字");
            new AlertDialog.Builder(this).setTitle("Input").
                    setMessage("請輸入").setPositiveButton("確定",(d,w)->{
                        //空白請輸入數字
                       //幫我輸入EditText的hint
                       //輸入的金額不可小於20
                    String nStr = edit.getText().toString();
                    if (nStr.isEmpty()){
                        nStr = "空白請輸入數字";
                    }else{
                        int n = Integer.parseInt(nStr);
                        if (n < 20){
                            nStr = "輸入的金額不可小於20";
                        }
                    }

                    Toast.makeText(MainActivity.this,nStr,Toast.LENGTH_SHORT).show();
            }).
                    setView(edit).show();

        });
        StringBuilder msg = new StringBuilder();
        btn3.setOnClickListener(v->{
            String[] fruits = new String[]{"Apple","Banana","Kiwi"};

            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,fruits);

            new AlertDialog.Builder(this).setTitle("Title").
                    setAdapter(arrayAdapter,(d,w)->{
//                        Log.d("Howard","w:"+fruits[w]);
                        msg.setLength(0);//清除StringBuilder
                        msg.append(arrayAdapter.getItem(w));
                        Log.d("Howard","w:"+arrayAdapter.getItem(w));
                    }).setPositiveButton("確定",(d,w)->{
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
            }).show();
//按下確定按鈕後彈出Toast 顯示選擇的項目
        });

        String[] array = {"MackBook Air","MacBook Pro","MacBook Pro Max"};
        boolean[]  selected = {false,true,false};
        btn4.setOnClickListener(v->{
                int[] selectIndex = {0,1,2};
              new AlertDialog.Builder(this).
                      setMultiChoiceItems(array,selected,(d,p,check)->{
                          selected[p] = check;
                      }).setPositiveButton("確定",(d,which)->{
                  String itemMsg = IntStream.of(selectIndex).filter(i->selected[i]).
                          mapToObj(i->array[i]).collect(Collectors.joining(","));
                  if (itemMsg.isEmpty()){
                      itemMsg = "無產品";
                  }
                  Toast.makeText(this,itemMsg,Toast.LENGTH_LONG).show();
              }).show();

        });

//選完按下確定 告訴我是選擇了什麼狀態
        btn5.setOnClickListener(v->{
                String[] status = {"已婚","未婚","一言難盡"};
            new AlertDialog.Builder(this).setTitle("感情狀態").
                    setSingleChoiceItems(status,1,(d,w)->{
                        Log.d("Howard","w:"+w);
                        selectedStatus= w;
                    }).
                    setPositiveButton("確定",(d,w)->{
                        Log.d("Howard","確定");
                        Log.d("Howard","status:"+status[selectedStatus]);

                    }).
                    show();

        });

        btn6.setOnClickListener(v->{
            View view =
                    getLayoutInflater().inflate(R.layout.dialog_layout,null,false);
            EditText accountEDT = view.findViewById(R.id.accountEDT);
            EditText passwordEDT = view.findViewById(R.id.passwordEDT);
            new AlertDialog.Builder(this).setTitle("請登入").
                    setView(view).setCancelable(false).
                    setPositiveButton("確定",(d,w)->{
                        String account = accountEDT.getText().toString();
                        String password =passwordEDT.getText().toString();
                        Log.d("Howard",account+":"+password);

                    }).show();
        //確定按紐
        //按下後告訴我帳號密碼是什麼

        });


    }

}