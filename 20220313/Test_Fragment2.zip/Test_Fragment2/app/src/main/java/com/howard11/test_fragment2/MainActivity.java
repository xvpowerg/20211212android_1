package com.howard11.test_fragment2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Fragment fragmentA,fragmentB,fragmentC;

    private void click(View view){
        fragmentA = new FragmentA();
        fragmentB = new FragmentB();
        fragmentC = new FragmentC();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        switch (view.getId()){
            case R.id.btn1:
                ft.replace(R.id.fragment_container,fragmentA).
                        addToBackStack("group1");
                ft.commit();
                break;
            case R.id.btn2:
                ft.replace(R.id.fragment_container,fragmentB)
                        .addToBackStack("group1");
                ft.commit();
                break;
            case R.id.btn3:
                ft.replace(R.id.fragment_container,fragmentC).addToBackStack("group1");
                ft.commit();
                break;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button bt1 = findViewById(R.id.btn1);
        Button bt2 = findViewById(R.id.btn2);
        Button bt3 = findViewById(R.id.btn3);
        bt1.setOnClickListener(this::click);
        bt2.setOnClickListener(this::click);
        bt3.setOnClickListener(this::click);

    }
}
