package com.howard11.test_notification;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TestNotificationActivity  extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification_layout);
       String msg =  getIntent().getStringExtra("msg");
       TextView msgTxt = findViewById(R.id.msgTxt);
        msgTxt.setText(msg);
    }

}
