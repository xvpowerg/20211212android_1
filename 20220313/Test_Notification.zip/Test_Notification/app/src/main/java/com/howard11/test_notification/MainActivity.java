package com.howard11.test_notification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private final String CHANNEL_ID = "C1";

    private void createChannel(){

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationManager notificationManager =
                    (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel tmpCh =  notificationManager.getNotificationChannel(CHANNEL_ID);
            if (tmpCh != null){
                return;
            }

            String name = "TestNotification";
            String desName = "desName";
            int importance =  NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel =
                    new NotificationChannel(CHANNEL_ID,name,importance);
            channel.setDescription(desName);
            notificationManager.createNotificationChannel(channel);
        }

    }
    private void testNotification1(View view){


        int id =1;
        NotificationCompat.Builder builder =  new NotificationCompat.Builder(this,CHANNEL_ID).
                setSmallIcon(R.drawable.ic_baseline_bluetooth_24).
                setContentTitle("TestNotification").
                setContentText("加入「瑪利歐」、「路易吉」等角色之後，樂高終於也宣布在超級瑪利歐系列加入「碧姬公主」" +
                        "，同時將推出冒險主機與城堡擴充盒組，預計在今年8月正式上市。\n" +
                        "跟先前推出的瑪利歐冒險主機、路易吉冒險主機等組合一樣，樂高在一年一度的" +
                        "瑪利歐日宣布將推出碧姬公主冒險主機，以及城堡擴充盒組，並且將成為樂高超級瑪利歐" +
                        "世界的全新入口，與黃色奇諾比奧攜手打敗敵人雷米與火焰泡泡，一起賺取金幣。\n" +
                        "而碧姬公主一樣能透過藍牙與瑪利歐或路易吉連線互動，並且一起組隊擊敗敵人。樂高更" +
                        "計畫在8月一同上市的全新擴充盒組增加水果配件，將可讓不同角色產生各自互動反應").
                setPriority(NotificationCompat.PRIORITY_DEFAULT);
        createChannel();
        NotificationManagerCompat.from(this).notify(id,builder.build());
    }

    private void testNotification2(View view){
        //不要跟之前的重複
        int id =2;
        NotificationCompat.Builder nb =
                new NotificationCompat.Builder(this,CHANNEL_ID);
        nb.setSmallIcon(R.drawable.ic_baseline_beach_access_24);
        nb.setContentTitle("Big Text");
        NotificationCompat.BigTextStyle bigStyle =
                new NotificationCompat.BigTextStyle().bigText("加入「瑪利歐」、「路易吉」等角色之後，樂高終於也宣布在超級瑪利歐系列加入「碧姬公主」" +
                        "，同時將推出冒險主機與城堡擴充盒組，預計在今年8月正式上市。\n" +
                        "跟先前推出的瑪利歐冒險主機、路易吉冒險主機等組合一樣，樂高在一年一度的" +
                        "瑪利歐日宣布將推出碧姬公主冒險主機，以及城堡擴充盒組，並且將成為樂高超級瑪利歐" +
                        "世界的全新入口，與黃色奇諾比奧攜手打敗敵人雷米與火焰泡泡，一起賺取金幣。\n" +
                        "而碧姬公主一樣能透過藍牙與瑪利歐或路易吉連線互動，並且一起組隊擊敗敵人。樂高更" +
                        "計畫在8月一同上市的全新擴充盒組增加水果配件，將可讓不同角色產生各自互動反應");
        nb.setStyle(bigStyle);
        nb.setPriority(NotificationCompat.PRIORITY_DEFAULT);
        createChannel();
        NotificationManagerCompat.from(this).notify(id,nb.build());

    }
    private void testNotification3(View view){
        int id =3;
        Intent openActivityIntent = new Intent(this,TestNotificationActivity.class);
        openActivityIntent.putExtra("msg","加入「瑪利歐」、「路易吉」等角色之後，樂高終於也宣布在超級瑪利歐系列加入「碧姬公主」" +
                "，同時將推出冒險主機與城堡擴充盒組，預計在今年8月正式上市。\n" +
                "跟先前推出的瑪利歐冒險主機、路易吉冒險主機等組合一樣，樂高在一年一度的" +
                "瑪利歐日宣布將推出碧姬公主冒險主機，以及城堡擴充盒組，並且將成為樂高超級瑪利歐" +
                "世界的全新入口，與黃色奇諾比奧攜手打敗敵人雷米與火焰泡泡，一起賺取金幣。\n" +
                "而碧姬公主一樣能透過藍牙與瑪利歐或路易吉連線互動，並且一起組隊擊敗敵人。樂高更" +
                "計畫在8月一同上市的全新擴充盒組增加水果配件，將可讓不同角色產生各自互動反應");
        openActivityIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_CLEAR_TASK);
        //PendingIntent.FLAG_UPDATE_CURRENT 會將目前的Intent做更新
        PendingIntent pendingIntent = PendingIntent.getActivity(this,100,
                openActivityIntent,PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder n =
                new NotificationCompat.Builder(this,CHANNEL_ID).
                        setSmallIcon(R.drawable.ic_baseline_announcement_24).
                        setContentTitle("Title").setContentText("有新訊息").
                        setPriority(NotificationCompat.PRIORITY_MAX).
                        setContentIntent(pendingIntent);
        NotificationManagerCompat.from(this).notify(id,n.build());
    }
    private int count = 0;
    private void testNotification4(View view){
            int max = 100;
            int id = 4;
            count+=10;
            NotificationCompat.Builder builder =
                    new NotificationCompat.Builder(this,CHANNEL_ID);
            builder.setContentTitle("Download...");
            builder.setContentText("Download in Progress!:"+count);
        builder.setSmallIcon(R.drawable.ic_baseline_cloud_download_24);
        builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);
        //NotificationManagerCompat.from(this).notify(id,builder.build());

        Runnable run = ()->{

            for (int i = 10;i<= 100;i+=10){
                builder.setProgress(max,i,false);
                NotificationManagerCompat.from(this).notify(id,builder.build());
                try{
                    Thread.sleep(1000);
                }catch (Exception ex){

                }
            }
            builder.setContentText("完成");
            builder.setProgress(0,0,false);
            NotificationManagerCompat.from(this).notify(id,builder.build());

        };
         Thread thread = new Thread(run);
         thread.start();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn1 = findViewById(R.id.btn1);
        Button btn2 = findViewById(R.id.btn2);
        Button btn3 = findViewById(R.id.btn3);
        Button btn4 = findViewById(R.id.btn4);
        btn1.setOnClickListener(this::testNotification1);
        btn2.setOnClickListener(this::testNotification2);
        btn3.setOnClickListener(this::testNotification3);
        btn4.setOnClickListener(this::testNotification4);
    }
}