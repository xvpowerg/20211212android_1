package com.howard11.test_fragment1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageFragment imageFragment;
    interface ChangeImage{
        void change(ImageView imageView);
    }
    private View.OnClickListener onclick = (view)->{
            int res = -1;
           switch (view.getId()){
               case R.id.image1Btn:
                   res = R.drawable.image1;
                   break;
               case R.id.image2Btn:
                   res = R.drawable.image2;
                   break;
               case R.id.image3Btn:
                   res = R.drawable.image3;
                   break;
           }
           int finaRes = res;
        imageFragment.changeImage(imageView ->{
            imageView.setImageResource(finaRes);
        } );

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);

        ButtonsFragment buttonsFragment =
              (ButtonsFragment)getSupportFragmentManager().
                      findFragmentById(R.id.btnFragment);
         imageFragment =
                (ImageFragment)getSupportFragmentManager().
                        findFragmentById(R.id.imageFragment);
        buttonsFragment.initBtnOnclick(onclick);

    }
}