package com.howard11.test_baseadapter2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import com.howard11.test_baseadapter2.adapter.ItemAdapter;
import com.howard11.test_baseadapter2.beans.Item;

public class MainActivity extends AppCompatActivity {
    private ItemAdapter itemAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView list =  findViewById(R.id.listView);
         itemAdapter = new ItemAdapter();
        Item item1 = new Item(10,"Item1");
        Item item2 = new Item(20,"Item2");
        Item item3 = new Item(30,"Item3");
        Item item4 = new Item(40,"Item4");
        itemAdapter.addItem(item1);
        itemAdapter.addItem(item2);
        itemAdapter.addItem(item3);
        itemAdapter.addItem(item4);

        list.setAdapter(itemAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
            getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //
        String msg = "";
            switch (item.getItemId()){
                case R.id.add_item:
                    msg = getString(R.string.add_item);
                    Item item4 = new Item(40,"Item4");
                    itemAdapter.addItem(item4);
                    itemAdapter.refresh();
                 break;
                case R.id.help:
                    msg = getString(R.string.help);
                    break;
            }
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
        return super.onOptionsItemSelected(item);
    }
}
