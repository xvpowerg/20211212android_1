package com.howard11.test_baseadapter2.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.howard11.test_baseadapter2.R;
import com.howard11.test_baseadapter2.beans.Item;

import java.util.ArrayList;
import java.util.List;

public class ItemAdapter extends BaseAdapter {
    private List<Item> datas = new ArrayList<Item>();

    public void refresh(){
        notifyDataSetChanged();
    }
    public void addItem(Item item){
        this.datas.add(item);
    }
    @Override
    public int getCount() {
        return datas.size();
    }

    @Override
    public Item getItem(int position) {
        return datas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return datas.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_layout,
                parent,false);
        TextView idTxt = view.findViewById(R.id.idTxt);
        TextView nameTxt = view.findViewById(R.id.nameTxt);
        Item item = this.getItem(position);
        idTxt.setText(item.getId()+"");
        nameTxt.setText(item.getName());
        return view;
    }
}
