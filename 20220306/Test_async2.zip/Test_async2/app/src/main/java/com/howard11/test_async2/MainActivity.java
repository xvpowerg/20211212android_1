package com.howard11.test_async2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView imageView = findViewById(R.id.imageView);
        Button startBtn = findViewById(R.id.startBtn);
        LoopImages loopImages = new LoopImages(imageView);
        startBtn.setOnClickListener(v -> {
                Thread loopThread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        loopImages.startLoop();
                    }
                });
            loopThread.start();

        });

        Button stopBtn = findViewById(R.id.stopBtn);
        stopBtn.setOnClickListener(v->{
            loopImages.stopLoop();

        });
    }
}