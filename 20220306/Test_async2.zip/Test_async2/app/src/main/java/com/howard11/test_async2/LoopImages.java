package com.howard11.test_async2;

import android.os.Handler;
import android.widget.ImageView;

import java.util.concurrent.TimeUnit;


public class LoopImages {
   private int[] images = {R.drawable.image1,R.drawable.image2,
           R.drawable.image3,R.drawable.image4};
   private int i = 0;
   private boolean stop = false;
   private ImageView imageView;
    private Handler handler = new Handler();
   public LoopImages(ImageView imageView){
       this.imageView = imageView;
   }

   public void startLoop(){
       stop = false;
       for(;i < images.length|| (i%=images.length)==0 ;i++  ){
           handler.post(new Runnable() {
               @Override
               public void run() {
                   imageView.setImageResource(images[i]);
               }
           });

                try{
                    TimeUnit.SECONDS.sleep(1);
                }catch(Exception ex){

                }
               if (stop){
                   break;
               }

       }
   }

   public void stopLoop(){
       stop = true;
   }

}
