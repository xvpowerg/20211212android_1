package com.howard11.test_android_async_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private int count = 100;
    private int[] images = {
            R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3,
            R.drawable.image4};

    private class MyRun implements Runnable{
            public void run(){
                boolean run = true;

                while(run){
                    if (count>= images.length){
                        break;
                    }
                    //運行在original thread
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (count < images.length){
                                imageView.setImageResource(images[count++]);
                            }

                        }
                    });
                    try{
                        TimeUnit.SECONDS.sleep(1);
                    }catch (Exception ex){

                    }

                }

            }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.imageView);
        Button startBtn = findViewById(R.id.startBtn);
        MyRun myRun = new MyRun();

        startBtn.setOnClickListener(v->{
            if (count < images.length){
                count = 100;
            }else{
                count = 0;
            }

            Thread t1 = new Thread(myRun);
            t1.start();
        });
    }
}