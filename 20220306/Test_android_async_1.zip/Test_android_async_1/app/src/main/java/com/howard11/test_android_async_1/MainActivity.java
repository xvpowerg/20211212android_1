package com.howard11.test_android_async_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private TextView countTxt;
    private class MyRunnable implements  Runnable{
            public void run(){
                for(int i = 5; i >= 0;i--){
                    countTxt.setText(i+"");
                    try{
                        TimeUnit.SECONDS.sleep(1);
                    }catch (Exception ex){

                    }

                }
            }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button startBtn =   findViewById(R.id.startBtn);
         countTxt = findViewById(R.id.countTxt);
        startBtn.setOnClickListener(v->{
            MyRunnable myRunnable = new MyRunnable();
            Thread t1 = new Thread(myRunnable);
            t1.start();

        });
    }
}